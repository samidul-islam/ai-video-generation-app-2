'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

import { useAuth } from '@/components/auth-provider'
import { cn } from '@/lib/utils'

export function HeaderNav() {
  const pathname = usePathname()
  const { me } = useAuth()
  const links = [
    { href: '/', label: 'Create' },
    { href: '/projects', label: 'Library' },
    ...(me?.is_admin ? [{ href: '/admin', label: 'Admin' }] : []),
  ]

  return (
    <nav aria-label="Main" className="hidden items-center gap-1 text-sm sm:flex">
      {links.map((link) => {
        const active = link.href === '/' ? pathname === '/' : pathname.startsWith(link.href)
        return (
          <Link
            key={link.href}
            href={link.href}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'rounded-full px-3 py-1.5 text-muted-foreground transition-colors hover:text-foreground',
              active && 'bg-secondary text-foreground',
            )}
          >
            {link.label}
          </Link>
        )
      })}
    </nav>
  )
}
