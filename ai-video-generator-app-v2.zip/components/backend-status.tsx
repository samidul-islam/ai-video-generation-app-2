'use client'

import useSWR from 'swr'
import { ServerOff } from 'lucide-react'

import { API_URL, SWR_KEYS, fetcher } from '@/lib/api'

export function BackendStatus() {
  const { error } = useSWR(SWR_KEYS.health, fetcher, {
    shouldRetryOnError: false,
    refreshInterval: (data) => (data ? 0 : 15000),
  })

  if (!error) return null

  return (
    <div role="status" className="border-b border-destructive/30 bg-destructive/10">
      <div className="mx-auto flex max-w-7xl items-start gap-3 px-4 py-2.5 text-sm md:px-6">
        <ServerOff className="mt-0.5 size-4 shrink-0 text-destructive" aria-hidden="true" />
        <p className="text-pretty">
          {"Can't reach the FastAPI backend at "}
          <code className="font-mono text-foreground">{API_URL}</code>
          {'. Start it with '}
          <code className="font-mono text-foreground">uvicorn app.main:app</code>
          {' or set '}
          <code className="font-mono text-foreground">NEXT_PUBLIC_API_URL</code>.
        </p>
      </div>
    </div>
  )
}
