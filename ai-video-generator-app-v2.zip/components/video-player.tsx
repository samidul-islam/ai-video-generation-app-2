'use client'

import { useState } from 'react'
import { Download } from 'lucide-react'

import { buttonVariants } from '@/components/ui/button'
import type { Project, Resolution } from '@/lib/types'
import { cn } from '@/lib/utils'

export function VideoPlayer({ project }: { project: Project }) {
  const sources: Partial<Record<Resolution, string>> = {
    '1080p': project.video_url_1080p ?? undefined,
    '720p': project.video_url_720p ?? undefined,
  }
  const available = (Object.keys(sources) as Resolution[]).filter((key) => sources[key])
  const [quality, setQuality] = useState<Resolution>(available[0] ?? '1080p')
  const src = sources[quality]

  if (!src) return null

  return (
    <div className="flex flex-col gap-3">
      <div className="overflow-hidden rounded-lg border border-border bg-black">
        <video
          key={src}
          src={src}
          poster={project.thumbnail_url ?? undefined}
          controls
          playsInline
          preload="metadata"
          className="aspect-video w-full"
        >
          <track kind="captions" />
        </video>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div role="radiogroup" aria-label="Playback quality" className="flex rounded-lg border border-border p-0.5">
          {available.map((option) => (
            <button
              key={option}
              type="button"
              role="radio"
              aria-checked={quality === option}
              onClick={() => setQuality(option)}
              className={cn(
                'rounded-md px-3 py-1 font-mono text-xs transition-colors',
                quality === option ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {option}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          {available.map((option) => (
            <a
              key={option}
              href={sources[option]}
              download
              target="_blank"
              rel="noopener noreferrer"
              className={buttonVariants({ variant: option === '1080p' ? 'default' : 'outline', size: 'sm' })}
            >
              <Download aria-hidden="true" />
              {option}
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}
