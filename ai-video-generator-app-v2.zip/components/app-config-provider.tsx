'use client'

import { createContext, useContext, useMemo } from 'react'
import useSWR from 'swr'

import { SWR_KEYS, fetcher } from '@/lib/api'
import { DEFAULT_CREDIT_CONFIG } from '@/lib/pricing'
import type { PublicConfig, ThemeConfig } from '@/lib/types'

export const DEFAULT_THEME: ThemeConfig = {
  primary: '#8b5cf6',
  accent: '#22d3ee',
  background: '#0b0b12',
  surface: '#15151f',
  foreground: '#f4f4f7',
  radius: 0.9,
  font: 'geist',
  hero_title: 'What will you create today?',
  hero_subtitle: 'Describe a scene in Bengali, Banglish or English. Put dialogue in quotes.',
  create_label: 'Create',
  prompt_placeholder: 'Describe the video. For the cleanest speech, put exact dialogue inside "quotes".',
}

export const DEFAULT_CONFIG: PublicConfig = {
  meta: {
    name: 'Chobi Studio',
    tagline: 'Script to screen, in any language',
    description: 'Turn Bengali, Banglish or English prompts into talking-avatar videos.',
    logo_url: '',
    favicon_url: '',
    support_email: '',
    maintenance_mode: false,
    allow_signups: true,
    video_retention_hours: 48,
  },
  credits: DEFAULT_CREDIT_CONFIG,
  theme: DEFAULT_THEME,
}

const ConfigContext = createContext<PublicConfig>(DEFAULT_CONFIG)

const FONTS: Record<ThemeConfig['font'], string> = {
  geist: 'var(--font-geist), var(--font-bengali), ui-sans-serif, system-ui, sans-serif',
  inter: 'Inter, var(--font-bengali), ui-sans-serif, system-ui, sans-serif',
  system: 'ui-sans-serif, system-ui, var(--font-bengali), sans-serif',
}

/** Maps the admin-editable theme onto the shadcn CSS variables. */
export function themeToCss(theme: ThemeConfig) {
  return `:root, :root.dark:not(.light) {
  --background: ${theme.background};
  --foreground: ${theme.foreground};
  --card: ${theme.surface};
  --card-foreground: ${theme.foreground};
  --popover: ${theme.surface};
  --popover-foreground: ${theme.foreground};
  --primary: ${theme.primary};
  --primary-foreground: #ffffff;
  --ring: ${theme.primary};
  --accent-brand: ${theme.accent};
  --chart-1: ${theme.primary};
  --chart-2: ${theme.accent};
  --sidebar-primary: ${theme.primary};
  --radius: ${theme.radius}rem;
  --font-sans: ${FONTS[theme.font]};
}`
}

export function AppConfigProvider({ children }: { children: React.ReactNode }) {
  const { data } = useSWR<PublicConfig>(SWR_KEYS.appConfig, fetcher, {
    shouldRetryOnError: false,
    revalidateOnFocus: false,
  })
  const config = useMemo<PublicConfig>(
    () =>
      data
        ? { meta: { ...DEFAULT_CONFIG.meta, ...data.meta }, credits: data.credits, theme: { ...DEFAULT_THEME, ...data.theme } }
        : DEFAULT_CONFIG,
    [data],
  )

  return (
    <ConfigContext.Provider value={config}>
      {data && <style>{themeToCss(config.theme)}</style>}
      {children}
    </ConfigContext.Provider>
  )
}

export function useAppConfig() {
  return useContext(ConfigContext)
}
