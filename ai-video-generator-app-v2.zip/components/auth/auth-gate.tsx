'use client'

import { Loader2 } from 'lucide-react'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect } from 'react'

import { useAuth } from '@/components/auth-provider'

export function AuthGate({ children, requireAdmin = false }: { children: React.ReactNode; requireAdmin?: boolean }) {
  const { ready, signedIn, me } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  const deniedAdmin = requireAdmin && me !== undefined && !me.is_admin

  useEffect(() => {
    if (ready && !signedIn) router.replace(`/login?next=${encodeURIComponent(pathname)}`)
    else if (deniedAdmin) router.replace('/')
  }, [ready, signedIn, deniedAdmin, pathname, router])

  const waitingForRole = requireAdmin && signedIn && me === undefined
  if (!ready || !signedIn || waitingForRole || deniedAdmin) {
    return (
      <div className="flex min-h-dvh items-center justify-center" role="status">
        <Loader2 className="size-6 animate-spin text-muted-foreground" aria-hidden="true" />
        <span className="sr-only">Loading</span>
      </div>
    )
  }
  return <>{children}</>
}
