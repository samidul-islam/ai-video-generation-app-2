'use client'

import { Loader2 } from 'lucide-react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useEffect, useState } from 'react'

import { useAppConfig } from '@/components/app-config-provider'
import { useAuth } from '@/components/auth-provider'
import { BrandMark } from '@/components/brand-mark'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function friendlyError(error: unknown) {
  const code = (error as { code?: string })?.code ?? ''
  if (code.includes('invalid-credential') || code.includes('wrong-password') || code.includes('user-not-found'))
    return 'Email or password is incorrect.'
  if (code.includes('email-already-in-use')) return 'An account with this email already exists.'
  if (code.includes('weak-password')) return 'Password must be at least 6 characters.'
  if (code.includes('too-many-requests')) return 'Too many attempts. Try again in a few minutes.'
  return error instanceof Error ? error.message : 'Something went wrong.'
}

export function AuthForm() {
  const { signIn, signUp, signedIn, ready, firebaseEnabled } = useAuth()
  const { meta } = useAppConfig()
  const router = useRouter()
  const next = useSearchParams().get('next') || '/'
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (ready && signedIn) router.replace(next.startsWith('/') ? next : '/')
  }, [ready, signedIn, next, router])

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const email = String(form.get('email') ?? '').trim()
    const password = String(form.get('password') ?? '')
    setPending(true)
    setError('')
    try {
      if (mode === 'signin') await signIn(email, password)
      else await signUp(String(form.get('name') ?? '').trim(), email, password)
    } catch (err) {
      setError(friendlyError(err))
    } finally {
      setPending(false)
    }
  }

  const isSignup = mode === 'signup'

  return (
    <div className="relative w-full max-w-sm">
      <div className="mb-8 flex justify-center">
        <BrandMark />
      </div>
      <div className="rounded-2xl border border-border bg-card/80 p-6 shadow-2xl shadow-primary/10 backdrop-blur">
        <h1 className="text-xl font-semibold tracking-tight">{isSignup ? 'Create your account' : 'Welcome back'}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {isSignup ? 'Start turning scripts into talking videos.' : meta.tagline}
        </p>

        {!firebaseEnabled ? (
          <p className="mt-6 rounded-lg border border-border bg-muted/40 p-3 text-sm text-muted-foreground">
            Firebase Auth isn&apos;t configured. Add the <code className="font-mono">NEXT_PUBLIC_FIREBASE_*</code>{' '}
            variables to enable sign-in. The backend&apos;s dev user is used meanwhile.
          </p>
        ) : (
          <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-4">
            {isSignup && (
              <div className="flex flex-col gap-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" name="name" autoComplete="name" required />
              </div>
            )}
            <div className="flex flex-col gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" autoComplete="email" required />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                minLength={6}
                autoComplete={isSignup ? 'new-password' : 'current-password'}
                required
              />
            </div>
            {error && (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            )}
            <Button type="submit" size="lg" disabled={pending} className="mt-1">
              {pending && <Loader2 className="animate-spin" aria-hidden="true" />}
              {isSignup ? 'Create account' : 'Sign in'}
            </Button>
          </form>
        )}

        {firebaseEnabled && meta.allow_signups && (
          <p className="mt-5 text-center text-sm text-muted-foreground">
            {isSignup ? 'Already have an account?' : 'New here?'}{' '}
            <button
              type="button"
              onClick={() => {
                setMode(isSignup ? 'signin' : 'signup')
                setError('')
              }}
              className="font-medium text-foreground underline-offset-4 hover:underline"
            >
              {isSignup ? 'Sign in' : 'Create an account'}
            </button>
          </p>
        )}
      </div>
    </div>
  )
}
