'use client'

import { LayoutDashboard, Library, LogOut, Sparkles } from 'lucide-react'
import { useRouter } from 'next/navigation'

import { useAuth } from '@/components/auth-provider'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

export function UserMenu() {
  const { me, user, firebaseEnabled, signOut } = useAuth()
  const router = useRouter()
  const name = me?.profile.name || user?.displayName || me?.profile.email || 'Creator'
  const email = me?.profile.email || user?.email || ''
  const photo = me?.profile.photo_url || user?.photoURL || ''

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label="Account menu"
        className="rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <Avatar className="size-8">
          {photo && <AvatarImage src={photo || '/placeholder.svg'} alt="" />}
          <AvatarFallback className="bg-primary/20 text-xs text-primary">{name.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuGroup>
          <DropdownMenuLabel className="flex flex-col gap-0.5">
            <span className="truncate text-sm font-medium text-foreground">{name}</span>
            {email && <span className="truncate text-xs font-normal text-muted-foreground">{email}</span>}
          </DropdownMenuLabel>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => router.push('/')}>
          <Sparkles aria-hidden="true" /> Create
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => router.push('/projects')}>
          <Library aria-hidden="true" /> Library
        </DropdownMenuItem>
        {me?.is_admin && (
          <DropdownMenuItem onClick={() => router.push('/admin')}>
            <LayoutDashboard aria-hidden="true" /> Admin panel
          </DropdownMenuItem>
        )}
        {firebaseEnabled && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={async () => {
                await signOut()
                router.replace('/login')
              }}
            >
              <LogOut aria-hidden="true" /> Sign out
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
