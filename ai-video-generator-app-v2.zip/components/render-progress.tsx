'use client'

import { useState } from 'react'
import { Check, Loader2, WifiOff } from 'lucide-react'
import { toast } from 'sonner'
import { useSWRConfig } from 'swr'

import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { VideoPlayer } from '@/components/video-player'
import { useJobProgress } from '@/hooks/use-job-progress'
import { SWR_KEYS, api } from '@/lib/api'
import { TERMINAL_STATUSES, type Project, type ProjectStatus } from '@/lib/types'
import { cn } from '@/lib/utils'

const STAGES: { label: string; reachedAt: number }[] = [
  { label: 'Queued on GPU', reachedAt: 0 },
  { label: 'Rendering frames', reachedAt: 25 },
  { label: 'Encoding & upload', reachedAt: 88 },
  { label: 'Ready', reachedAt: 100 },
]

interface RenderProgressProps {
  projectId: string
  initialProject?: Project
}

export function RenderProgress({ projectId, initialProject }: RenderProgressProps) {
  const { mutate } = useSWRConfig()
  const alreadyFinished = initialProject ? TERMINAL_STATUSES.includes(initialProject.status) : false
  const { event, connectionLost } = useJobProgress(alreadyFinished ? null : projectId)
  const [cancelling, setCancelling] = useState(false)

  const project = event?.project ?? initialProject
  const status: ProjectStatus = event?.status ?? initialProject?.status ?? 'queued'
  const progress = event?.progress ?? initialProject?.progress ?? 0
  const message = event?.message ?? initialProject?.status_message ?? 'Connecting…'
  const active = status === 'queued' || status === 'rendering'

  async function cancel() {
    setCancelling(true)
    try {
      await api.cancelJob(projectId)
      mutate(SWR_KEYS.credits)
      toast.success('Render cancelled. Credits refunded.')
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Could not cancel render.')
    } finally {
      setCancelling(false)
    }
  }

  if (status === 'completed' && project) {
    return <VideoPlayer project={project} />
  }

  if (status === 'failed' || status === 'cancelled') {
    return (
      <div className="flex flex-col gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-4">
        <p className="font-medium">{status === 'failed' ? 'Render failed' : 'Render cancelled'}</p>
        <p className="text-sm text-muted-foreground text-pretty">
          {project?.error ?? message}
          {project?.credits_refunded ? ' Your credits have been refunded.' : ''}
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="relative flex aspect-video items-center justify-center overflow-hidden rounded-lg border border-border bg-card">
        <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-primary/10 via-transparent to-primary/5" />
        <div className="relative flex flex-col items-center gap-2 text-center">
          <span className="font-mono text-4xl tabular-nums">{`${progress}%`}</span>
          <span className="text-sm text-muted-foreground" aria-live="polite">
            {message}
          </span>
        </div>
      </div>

      <Progress value={progress} aria-label="Render progress" />

      <ol className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {STAGES.map((stage, index) => {
          const next = STAGES[index + 1]
          const done = next ? progress >= next.reachedAt : progress >= 100
          const current = !done && progress >= stage.reachedAt
          return (
            <li
              key={stage.label}
              className={cn(
                'flex items-center gap-2 rounded-md border px-2.5 py-2 text-xs',
                done && 'border-primary/40 text-foreground',
                current && 'border-primary bg-primary/10 text-foreground',
                !done && !current && 'border-border text-muted-foreground',
              )}
            >
              {done ? (
                <Check className="size-3.5 text-primary" aria-hidden="true" />
              ) : current ? (
                <Loader2 className="size-3.5 animate-spin text-primary" aria-hidden="true" />
              ) : (
                <span className="size-3.5 rounded-full border border-border" aria-hidden="true" />
              )}
              {stage.label}
            </li>
          )
        })}
      </ol>

      <div className="flex items-center justify-between gap-3">
        {connectionLost ? (
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <WifiOff className="size-3.5" aria-hidden="true" />
            Reconnecting to progress stream…
          </p>
        ) : (
          <p className="text-xs text-muted-foreground">You can leave this page — the render keeps running.</p>
        )}
        {active && (
          <Button variant="outline" size="sm" onClick={cancel} disabled={cancelling}>
            {cancelling ? 'Cancelling…' : 'Cancel render'}
          </Button>
        )}
      </div>
    </div>
  )
}
