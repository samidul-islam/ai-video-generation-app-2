'use client'

import Link from 'next/link'
import { Sparkles } from 'lucide-react'

import { useAppConfig } from '@/components/app-config-provider'

export function BrandMark({ href = '/' }: { href?: string }) {
  const { meta } = useAppConfig()
  return (
    <Link href={href} className="flex items-center gap-2 font-semibold tracking-tight">
      {meta.logo_url ? (
        <img src={meta.logo_url || '/placeholder.svg'} alt="" className="size-7 rounded-md object-cover" />
      ) : (
        <span className="flex size-7 items-center justify-center rounded-md bg-gradient-to-br from-primary to-[var(--accent-brand)] text-primary-foreground">
          <Sparkles className="size-4" aria-hidden="true" />
        </span>
      )}
      <span>{meta.name}</span>
    </Link>
  )
}
