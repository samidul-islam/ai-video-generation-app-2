'use client'

import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import type { ParsedPrompt } from '@/lib/types'

const FIELDS: { key: keyof ParsedPrompt; label: string; hint: string; bengali?: boolean; rows: number }[] = [
  { key: 'visual_prompt', label: 'Visual direction', hint: 'Camera, lighting, setting and action.', rows: 4 },
  { key: 'character_mapping', label: 'Character mapping', hint: 'Which reference image plays whom.', rows: 2 },
  { key: 'dialogue', label: 'Dialogue', hint: 'Spoken lines in Bengali script.', bengali: true, rows: 3 },
  { key: 'sound_effects', label: 'Sound effects', hint: 'Ambience and foley cues.', rows: 2 },
  { key: 'full_minimax_prompt', label: 'Final MiniMax prompt', hint: 'Exactly what is sent to the model.', rows: 6 },
]

interface ParsedPromptEditorProps {
  value: ParsedPrompt
  onChange: (value: ParsedPrompt) => void
  disabled?: boolean
}

export function ParsedPromptEditor({ value, onChange, disabled }: ParsedPromptEditorProps) {
  return (
    <div className="flex flex-col gap-4">
      {FIELDS.map((field) => {
        const id = `parsed-${field.key}`
        return (
          <div key={field.key} className="flex flex-col gap-1.5">
            <div className="flex items-baseline justify-between gap-3">
              <Label htmlFor={id}>{field.label}</Label>
              <span className="text-xs text-muted-foreground">{field.hint}</span>
            </div>
            <Textarea
              id={id}
              rows={field.rows}
              lang={field.bengali ? 'bn' : undefined}
              value={value[field.key]}
              disabled={disabled}
              onChange={(event) => onChange({ ...value, [field.key]: event.target.value })}
              className={field.key === 'full_minimax_prompt' ? 'font-mono text-xs leading-relaxed' : 'leading-relaxed'}
            />
          </div>
        )
      })}
    </div>
  )
}
