'use client'

import { AudioWaveform, Mic } from 'lucide-react'

import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { AudioMode, TtsProvider } from '@/lib/types'
import { cn } from '@/lib/utils'

const MODES: { value: AudioMode; title: string; description: string; icon: typeof Mic }[] = [
  {
    value: 'native',
    title: 'Native audio',
    description: 'MiniMax generates voice and sound in one pass.',
    icon: AudioWaveform,
  },
  {
    value: 'hq_bengali',
    title: 'HQ Bengali voice',
    description: 'Studio TTS voice, lip-synced to your characters.',
    icon: Mic,
  },
]

const PROVIDERS: Record<TtsProvider, string> = {
  google_chirp: 'Google Chirp 3 HD',
  elevenlabs: 'ElevenLabs Multilingual',
}

interface AudioModePickerProps {
  mode: AudioMode
  provider: TtsProvider
  onModeChange: (mode: AudioMode) => void
  onProviderChange: (provider: TtsProvider) => void
  disabled?: boolean
}

export function AudioModePicker({ mode, provider, onModeChange, onProviderChange, disabled }: AudioModePickerProps) {
  return (
    <div className="flex flex-col gap-4">
      <div role="radiogroup" aria-label="Audio mode" className="grid gap-3 sm:grid-cols-2">
        {MODES.map((option) => {
          const selected = option.value === mode
          const Icon = option.icon
          return (
            <button
              key={option.value}
              type="button"
              role="radio"
              aria-checked={selected}
              disabled={disabled}
              onClick={() => onModeChange(option.value)}
              className={cn(
                'flex items-start gap-3 rounded-lg border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50',
                selected ? 'border-primary bg-primary/10' : 'border-border bg-card/50 hover:border-muted-foreground/40',
              )}
            >
              <Icon className={cn('mt-0.5 size-4 shrink-0', selected ? 'text-primary' : 'text-muted-foreground')} aria-hidden="true" />
              <span className="flex flex-col gap-0.5">
                <span className="text-sm font-medium">{option.title}</span>
                <span className="text-xs leading-relaxed text-muted-foreground">{option.description}</span>
              </span>
            </button>
          )
        })}
      </div>

      {mode === 'hq_bengali' && (
        <div className="flex flex-col gap-2">
          <Label htmlFor="tts-provider">Voice provider</Label>
          <Select
            items={PROVIDERS}
            value={provider}
            onValueChange={(value) => value && onProviderChange(value as TtsProvider)}
            disabled={disabled}
          >
            <SelectTrigger id="tts-provider" className="w-full sm:w-72">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(PROVIDERS).map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  )
}
