'use client'

import { useRef } from 'react'
import { ImagePlus, X } from 'lucide-react'

import { Button } from '@/components/ui/button'

export const MAX_REFERENCES = 4
const MAX_BYTES = 10 * 1024 * 1024

export interface ReferenceImage {
  id: string
  file: File
  previewUrl: string
  uploadedUrl?: string
}

interface ReferenceUploaderProps {
  images: ReferenceImage[]
  onChange: (images: ReferenceImage[]) => void
  onReject: (message: string) => void
  disabled?: boolean
}

export function ReferenceUploader({ images, onChange, onReject, disabled }: ReferenceUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  function addFiles(fileList: FileList | null) {
    if (!fileList) return
    const room = MAX_REFERENCES - images.length
    const accepted: ReferenceImage[] = []
    for (const file of Array.from(fileList)) {
      if (accepted.length >= room) {
        onReject(`You can add up to ${MAX_REFERENCES} reference images.`)
        break
      }
      if (!file.type.startsWith('image/')) {
        onReject(`${file.name} is not an image.`)
        continue
      }
      if (file.size > MAX_BYTES) {
        onReject(`${file.name} is larger than 10 MB.`)
        continue
      }
      accepted.push({ id: crypto.randomUUID(), file, previewUrl: URL.createObjectURL(file) })
    }
    if (accepted.length) onChange([...images, ...accepted])
    if (inputRef.current) inputRef.current.value = ''
  }

  function remove(id: string) {
    const target = images.find((image) => image.id === id)
    if (target) URL.revokeObjectURL(target.previewUrl)
    onChange(images.filter((image) => image.id !== id))
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {images.map((image, index) => (
          <figure
            key={image.id}
            className="group relative aspect-[3/4] overflow-hidden rounded-lg border border-border bg-muted"
          >
            <img
              src={image.previewUrl || '/placeholder.svg'}
              alt={`Reference for Image ${index + 1}`}
              className="size-full object-cover"
            />
            <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 pb-1.5 pt-6 font-mono text-xs text-white">
              {`Image ${index + 1}`}
            </figcaption>
            <Button
              type="button"
              size="icon-xs"
              variant="secondary"
              className="absolute right-1.5 top-1.5 opacity-90"
              onClick={() => remove(image.id)}
              disabled={disabled}
              aria-label={`Remove Image ${index + 1}`}
            >
              <X />
            </Button>
          </figure>
        ))}

        {images.length < MAX_REFERENCES && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={disabled}
            className="flex aspect-[3/4] flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border bg-card/50 text-sm text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
          >
            <ImagePlus className="size-5" aria-hidden="true" />
            <span>{`Add Image ${images.length + 1}`}</span>
          </button>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        multiple
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
        onChange={(event) => addFiles(event.target.files)}
      />
      <p className="text-xs text-muted-foreground">
        {'Refer to characters in your script as "Image 1", "Image 2"… PNG, JPG or WebP up to 10 MB.'}
      </p>
    </div>
  )
}
