'use client'

import { ArrowUp, ImagePlus, Loader2, X } from 'lucide-react'
import { useRef, useState } from 'react'
import { toast } from 'sonner'
import useSWR, { useSWRConfig } from 'swr'

import { useAppConfig } from '@/components/app-config-provider'
import { GenerationSettings, type GenerationSettingsValue } from '@/components/studio/generation-settings'
import { Button } from '@/components/ui/button'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { SWR_KEYS, api, fetcher } from '@/lib/api'
import { videoCost } from '@/lib/pricing'
import type { CreditsResponse } from '@/lib/types'
import { cn } from '@/lib/utils'

const MAX_REFERENCES = 4
const MAX_BYTES = 10 * 1024 * 1024

interface ReferenceImage {
  id: string
  file: File
  previewUrl: string
}

type Phase = 'idle' | 'uploading' | 'parsing' | 'voicing' | 'queueing'

const PHASE_LABEL: Record<Phase, string> = {
  idle: '',
  uploading: 'Uploading references…',
  parsing: 'Directing the scene…',
  voicing: 'Recording voice…',
  queueing: 'Sending to GPU…',
}

export function Studio() {
  const { credits, theme } = useAppConfig()
  const { mutate } = useSWRConfig()
  const { data: balance } = useSWR<CreditsResponse>(SWR_KEYS.credits, fetcher, { shouldRetryOnError: false })
  const fileInput = useRef<HTMLInputElement>(null)

  const [prompt, setPrompt] = useState('')
  const [images, setImages] = useState<ReferenceImage[]>([])
  const [phase, setPhase] = useState<Phase>('idle')
  const [settings, setSettings] = useState<GenerationSettingsValue>({
    resolution: '720p',
    aspectRatio: '16:9',
    duration: 5,
    audioMode: 'native',
    ttsProvider: 'google_chirp',
  })

  const cost = videoCost(credits, settings.resolution, settings.duration, settings.audioMode === 'native')
  const busy = phase !== 'idle'
  const insufficient = balance !== undefined && balance.balance < cost
  const canSubmit = prompt.trim().length >= 3 && !busy && !insufficient

  function addFiles(list: FileList | null) {
    if (!list) return
    const next: ReferenceImage[] = []
    for (const file of Array.from(list)) {
      if (images.length + next.length >= MAX_REFERENCES) {
        toast.error(`Up to ${MAX_REFERENCES} reference images.`)
        break
      }
      if (!file.type.startsWith('image/') || file.size > MAX_BYTES) {
        toast.error(`${file.name} must be an image under 10 MB.`)
        continue
      }
      next.push({ id: crypto.randomUUID(), file, previewUrl: URL.createObjectURL(file) })
    }
    setImages((current) => [...current, ...next])
    if (fileInput.current) fileInput.current.value = ''
  }

  function removeImage(id: string) {
    setImages((current) => {
      const target = current.find((image) => image.id === id)
      if (target) URL.revokeObjectURL(target.previewUrl)
      return current.filter((image) => image.id !== id)
    })
  }

  async function submit() {
    if (!canSubmit) return
    try {
      let referenceUrls: string[] = []
      if (images.length) {
        setPhase('uploading')
        referenceUrls = (await api.uploadReferences(images.map((image) => image.file))).urls
      }

      setPhase('parsing')
      const parsed = await api.parsePrompt(prompt.trim(), images.length)

      let audioUrl: string | null = null
      if (settings.audioMode === 'hq_bengali' && parsed.dialogue.trim()) {
        setPhase('voicing')
        audioUrl = (await api.generateAudio(parsed.dialogue, settings.ttsProvider)).audio_url
      }

      setPhase('queueing')
      await api.generateVideo({
        title: prompt.trim().slice(0, 60),
        mode: images.length ? 'image-to-video' : 'text-to-video',
        raw_prompt: prompt.trim(),
        parsed_prompt: parsed,
        audio_mode: settings.audioMode,
        tts_provider: settings.audioMode === 'hq_bengali' ? settings.ttsProvider : null,
        audio_url: audioUrl,
        reference_image_urls: referenceUrls,
        resolution: settings.resolution,
        aspect_ratio: settings.aspectRatio,
        duration_seconds: settings.duration,
      })

      toast.success('Rendering started. It will appear below.')
      setPrompt('')
      images.forEach((image) => URL.revokeObjectURL(image.previewUrl))
      setImages([])
      mutate(SWR_KEYS.credits)
      mutate(SWR_KEYS.projects)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Generation failed.')
    } finally {
      setPhase('idle')
    }
  }

  return (
    <section aria-labelledby="studio-title" className="flex flex-col items-center gap-8">
      <div className="flex max-w-2xl flex-col items-center gap-3 text-center">
        <h1 id="studio-title" className="text-balance text-4xl font-semibold tracking-tight md:text-5xl">
          {theme.hero_title}
        </h1>
        <p className="text-pretty text-muted-foreground">{theme.hero_subtitle}</p>
      </div>

      <div
        className={cn(
          'w-full max-w-3xl rounded-3xl border border-border bg-card/80 p-3 shadow-2xl shadow-primary/10 backdrop-blur transition-colors focus-within:border-primary/60',
          busy && 'opacity-90',
        )}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault()
          addFiles(event.dataTransfer.files)
        }}
      >
        {images.length > 0 && (
          <ul className="flex flex-wrap gap-2 px-2 pt-2" aria-label="Reference images">
            {images.map((image, index) => (
              <li key={image.id} className="group relative size-16 overflow-hidden rounded-xl border border-border">
                <img
                  src={image.previewUrl || '/placeholder.svg'}
                  alt={`Reference ${index + 1}`}
                  className="size-full object-cover"
                />
                <span className="absolute bottom-0.5 left-1 font-mono text-[10px] text-white drop-shadow">
                  {index + 1}
                </span>
                <button
                  type="button"
                  onClick={() => removeImage(image.id)}
                  disabled={busy}
                  aria-label={`Remove reference ${index + 1}`}
                  className="absolute right-1 top-1 flex size-5 items-center justify-center rounded-full bg-black/70 text-white opacity-0 transition-opacity focus-visible:opacity-100 group-hover:opacity-100"
                >
                  <X className="size-3" aria-hidden="true" />
                </button>
              </li>
            ))}
          </ul>
        )}

        <label htmlFor="prompt" className="sr-only">
          Video prompt
        </label>
        <textarea
          id="prompt"
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          onKeyDown={(event) => {
            if (event.key !== 'Enter' || event.shiftKey) return
            if (event.nativeEvent.isComposing || event.keyCode === 229) return
            event.preventDefault()
            submit()
          }}
          disabled={busy}
          rows={3}
          maxLength={4000}
          placeholder={theme.prompt_placeholder}
          className="block max-h-64 min-h-24 w-full resize-none bg-transparent px-3 py-3 text-base leading-relaxed outline-none placeholder:text-muted-foreground/70"
        />

        <div className="flex flex-wrap items-center gap-2 px-1 pb-1">
          <input
            ref={fileInput}
            type="file"
            accept="image/*"
            multiple
            className="sr-only"
            tabIndex={-1}
            onChange={(event) => addFiles(event.target.files)}
          />
          <Tooltip>
            <TooltipTrigger
              render={
                <Button
                  variant="secondary"
                  size="icon-sm"
                  className="rounded-full"
                  aria-label="Add reference images"
                  disabled={busy || images.length >= MAX_REFERENCES}
                  onClick={() => fileInput.current?.click()}
                >
                  <ImagePlus aria-hidden="true" />
                </Button>
              }
            />
            <TooltipContent>Add up to 4 character references</TooltipContent>
          </Tooltip>

          <GenerationSettings value={settings} onChange={setSettings} disabled={busy} />

          <div className="ml-auto flex items-center gap-3">
            {busy ? (
              <span className="text-xs text-muted-foreground" aria-live="polite">
                {PHASE_LABEL[phase]}
              </span>
            ) : insufficient ? (
              <span className="text-xs text-destructive">Not enough credits</span>
            ) : null}
            <Button onClick={submit} disabled={!canSubmit} className="gap-2 rounded-full pl-4 pr-3">
              {theme.create_label}
              <span className="rounded-full bg-primary-foreground/15 px-2 py-0.5 font-mono text-xs tabular-nums">
                {cost} cr
              </span>
              {busy ? (
                <Loader2 className="animate-spin" aria-hidden="true" />
              ) : (
                <ArrowUp aria-hidden="true" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
