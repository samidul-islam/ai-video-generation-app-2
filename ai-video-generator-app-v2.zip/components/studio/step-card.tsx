import type { ReactNode } from 'react'

import { cn } from '@/lib/utils'

interface StepCardProps {
  step: number
  title: string
  description?: string
  action?: ReactNode
  children: ReactNode
  muted?: boolean
}

export function StepCard({ step, title, description, action, children, muted }: StepCardProps) {
  const headingId = `step-${step}-title`
  return (
    <section
      aria-labelledby={headingId}
      className={cn('rounded-xl border border-border bg-card p-4 md:p-5', muted && 'opacity-60')}
    >
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-secondary font-mono text-xs">
            {step}
          </span>
          <div className="flex flex-col gap-0.5">
            <h2 id={headingId} className="font-medium leading-6">
              {title}
            </h2>
            {description && <p className="text-sm text-muted-foreground">{description}</p>}
          </div>
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}
