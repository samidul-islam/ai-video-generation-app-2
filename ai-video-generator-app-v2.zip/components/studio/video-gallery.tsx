'use client'

import { AlertTriangle, Clock, Film, Loader2, Play } from 'lucide-react'
import { useState } from 'react'
import useSWR from 'swr'

import { DeleteProjectButton } from '@/components/projects/delete-project-button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { VideoPlayer } from '@/components/video-player'
import { useJobProgress } from '@/hooks/use-job-progress'
import { SWR_KEYS, fetcher } from '@/lib/api'
import type { Project, ProjectList } from '@/lib/types'

function aspectStyle(ratio: string) {
  const [w, h] = ratio.split(':').map(Number)
  return { aspectRatio: `${w} / ${h}` }
}

function expiresLabel(project: Project) {
  if (!project.expires_at) return null
  const hours = Math.max(0, Math.round((new Date(project.expires_at).getTime() - Date.now()) / 3_600_000))
  return hours < 1 ? 'Expires soon' : `Expires in ${hours}h`
}

function ActiveCard({ project }: { project: Project }) {
  const { event } = useJobProgress(project.id)
  const progress = event?.progress ?? project.progress
  const message = event?.message ?? project.status_message ?? 'Queued'
  return (
    <div className="flex size-full flex-col items-center justify-center gap-3 bg-[radial-gradient(circle_at_center,color-mix(in_oklch,var(--primary)_25%,transparent),transparent_70%)] p-4 text-center">
      <Loader2 className="size-6 animate-spin text-primary" aria-hidden="true" />
      <p className="line-clamp-2 text-xs text-muted-foreground">{message}</p>
      <Progress value={progress} className="h-1 w-3/4" aria-label="Render progress" />
      <span className="font-mono text-xs tabular-nums">{Math.round(progress)}%</span>
    </div>
  )
}

function GalleryCard({ project, onOpen }: { project: Project; onOpen: () => void }) {
  const active = project.status === 'queued' || project.status === 'rendering'
  const video = project.video_url_1080p ?? project.video_url_720p
  const done = project.status === 'completed' && video

  return (
    <article className="mb-4 break-inside-avoid overflow-hidden rounded-2xl border border-border bg-card">
      <button
        type="button"
        onClick={onOpen}
        disabled={!done}
        className="group relative block w-full bg-muted/40 text-left"
        style={aspectStyle(project.aspect_ratio)}
        aria-label={done ? `Play ${project.title}` : project.title}
      >
        {active ? (
          <ActiveCard project={project} />
        ) : done ? (
          <>
            <video
              src={`${video}#t=0.1`}
              poster={project.thumbnail_url ?? undefined}
              muted
              playsInline
              preload="metadata"
              className="size-full object-cover"
              onMouseEnter={(event) => event.currentTarget.play().catch(() => {})}
              onMouseLeave={(event) => {
                event.currentTarget.pause()
                event.currentTarget.currentTime = 0.1
              }}
            />
            <span className="absolute inset-0 flex items-center justify-center bg-black/0 transition-colors group-hover:bg-black/20">
              <span className="flex size-10 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition-opacity group-hover:opacity-100">
                <Play className="size-4 fill-current" aria-hidden="true" />
              </span>
            </span>
          </>
        ) : (
          <div className="flex size-full flex-col items-center justify-center gap-2 p-4 text-center text-muted-foreground">
            {project.status === 'failed' ? (
              <AlertTriangle className="size-5 text-destructive" aria-hidden="true" />
            ) : (
              <Film className="size-5" aria-hidden="true" />
            )}
            <span className="line-clamp-2 text-xs">
              {project.status === 'failed' ? (project.error ?? 'Render failed — credits refunded') : project.status}
            </span>
          </div>
        )}
        <span className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-0.5 font-mono text-[10px] text-white">
          {project.resolution} · {project.duration_seconds}s
        </span>
      </button>
      <div className="flex items-start justify-between gap-2 p-3">
        <div className="min-w-0">
          <h3 className="truncate text-sm font-medium">{project.title || project.raw_prompt}</h3>
          {done && expiresLabel(project) && (
            <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="size-3" aria-hidden="true" />
              {expiresLabel(project)}
            </p>
          )}
        </div>
        {!active && <DeleteProjectButton projectId={project.id} title={project.title} />}
      </div>
    </article>
  )
}

export function VideoGallery() {
  const { data, isLoading } = useSWR<ProjectList>(SWR_KEYS.projects, fetcher, { shouldRetryOnError: false })
  const [openId, setOpenId] = useState<string | null>(null)
  const items = data?.items ?? []
  const open = items.find((item) => item.id === openId)

  return (
    <section aria-labelledby="gallery-title" className="flex flex-col gap-4">
      <div className="flex items-baseline justify-between">
        <h2 id="gallery-title" className="text-lg font-semibold tracking-tight">
          Your creations
        </h2>
        <span className="text-xs text-muted-foreground">Videos are kept for 48 hours — download to keep</span>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 4 }, (_, i) => (
            <Skeleton key={i} className="aspect-video rounded-2xl" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-border py-16 text-center">
          <Film className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">Nothing here yet. Your videos will appear as they render.</p>
        </div>
      ) : (
        <div className="columns-2 gap-4 md:columns-3 lg:columns-4">
          {items.map((project) => (
            <GalleryCard key={project.id} project={project} onOpen={() => setOpenId(project.id)} />
          ))}
        </div>
      )}

      <Dialog open={Boolean(open)} onOpenChange={(next) => !next && setOpenId(null)}>
        <DialogContent className="max-w-3xl sm:max-w-3xl">
          {open && (
            <>
              <DialogHeader>
                <DialogTitle className="truncate">{open.title || 'Untitled'}</DialogTitle>
                <DialogDescription className="line-clamp-2">{open.raw_prompt}</DialogDescription>
              </DialogHeader>
              <VideoPlayer project={open} />
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
