'use client'

import { SlidersHorizontal } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Slider } from '@/components/ui/slider'
import { ASPECT_RATIOS, RESOLUTIONS, aspectBox } from '@/lib/pricing'
import type { AspectRatio, AudioMode, Resolution, TtsProvider } from '@/lib/types'
import { cn } from '@/lib/utils'

export interface GenerationSettingsValue {
  resolution: Resolution
  aspectRatio: AspectRatio
  duration: number
  audioMode: AudioMode
  ttsProvider: TtsProvider
}

interface Option<T extends string> {
  value: T
  label: string
  hint?: string
}

function Segmented<T extends string>({
  label,
  options,
  value,
  onChange,
  columns = 4,
  renderIcon,
}: {
  label: string
  options: Option<T>[]
  value: T
  onChange: (value: T) => void
  columns?: number
  renderIcon?: (value: T) => React.ReactNode
}) {
  return (
    <fieldset className="flex flex-col gap-2">
      <legend className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</legend>
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}>
        {options.map((option) => {
          const selected = option.value === value
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={selected}
              onClick={() => onChange(option.value)}
              className={cn(
                'flex flex-col items-center justify-center gap-1 rounded-lg border px-2 py-2 text-xs transition-colors',
                selected
                  ? 'border-primary bg-primary/15 text-foreground'
                  : 'border-border text-muted-foreground hover:border-foreground/30 hover:text-foreground',
              )}
            >
              {renderIcon?.(option.value)}
              <span className="font-medium">{option.label}</span>
              {option.hint && <span className="text-[10px] text-muted-foreground">{option.hint}</span>}
            </button>
          )
        })}
      </div>
    </fieldset>
  )
}

function AspectIcon({ ratio }: { ratio: AspectRatio }) {
  const { width, height } = aspectBox(ratio, 16)
  return (
    <span className="flex size-5 items-center justify-center" aria-hidden="true">
      <span className="rounded-[3px] border-[1.5px] border-current" style={{ width, height }} />
    </span>
  )
}

export function GenerationSettings({
  value,
  onChange,
  disabled,
}: {
  value: GenerationSettingsValue
  onChange: (value: GenerationSettingsValue) => void
  disabled?: boolean
}) {
  const set = <K extends keyof GenerationSettingsValue>(key: K, next: GenerationSettingsValue[K]) =>
    onChange({ ...value, [key]: next })

  return (
    <Popover>
      <PopoverTrigger
        disabled={disabled}
        render={
          <Button variant="secondary" size="sm" className="gap-2 rounded-full">
            <SlidersHorizontal aria-hidden="true" />
            <span className="font-mono text-xs">
              {value.resolution} · {value.aspectRatio} · {value.duration}s
            </span>
          </Button>
        }
      />
      <PopoverContent align="start" side="top" sideOffset={10} className="flex w-[22rem] flex-col gap-5 p-4">
        <Segmented
          label="Resolution"
          options={RESOLUTIONS.map((r) => ({ value: r, label: r }))}
          value={value.resolution}
          onChange={(next) => set('resolution', next)}
        />
        <Segmented
          label="Aspect ratio"
          options={ASPECT_RATIOS.map((r) => ({ value: r, label: r }))}
          value={value.aspectRatio}
          onChange={(next) => set('aspectRatio', next)}
          renderIcon={(ratio) => <AspectIcon ratio={ratio} />}
        />
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span id="duration-label" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Duration
            </span>
            <span className="font-mono text-sm tabular-nums">{value.duration}s</span>
          </div>
          <Slider
            aria-labelledby="duration-label"
            min={1}
            max={20}
            step={1}
            value={[value.duration]}
            onValueChange={(next) => set('duration', Array.isArray(next) ? next[0] : next)}
          />
        </div>
        <Segmented
          label="Audio"
          columns={2}
          options={[
            { value: 'native', label: 'Native', hint: 'Model voices it' },
            { value: 'hq_bengali', label: 'HQ voice', hint: 'Studio TTS' },
          ]}
          value={value.audioMode}
          onChange={(next) => set('audioMode', next)}
        />
        {value.audioMode === 'hq_bengali' && (
          <Segmented
            label="Voice engine"
            columns={2}
            options={[
              { value: 'google_chirp', label: 'Google Chirp' },
              { value: 'elevenlabs', label: 'ElevenLabs' },
            ]}
            value={value.ttsProvider}
            onChange={(next) => set('ttsProvider', next)}
          />
        )}
      </PopoverContent>
    </Popover>
  )
}
