'use client'

import useSWR from 'swr'
import { Coins } from 'lucide-react'

import { SWR_KEYS, fetcher } from '@/lib/api'
import type { CreditsResponse } from '@/lib/types'

export function CreditsBadge() {
  const { data, error } = useSWR<CreditsResponse>(SWR_KEYS.credits, fetcher, { shouldRetryOnError: false })
  const label = error ? '—' : data ? data.balance.toLocaleString() : '…'

  return (
    <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-sm">
      <Coins className="size-4 text-primary" aria-hidden="true" />
      <span className="font-mono tabular-nums">{label}</span>
      <span className="text-muted-foreground">credits</span>
    </div>
  )
}
