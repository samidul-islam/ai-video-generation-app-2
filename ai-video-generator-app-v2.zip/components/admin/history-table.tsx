'use client'

import { Search } from 'lucide-react'
import { useState } from 'react'
import useSWR from 'swr'

import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { SWR_KEYS, fetcher } from '@/lib/api'
import { RESOLUTIONS } from '@/lib/pricing'
import type { HistoryItem } from '@/lib/types'

const STATUSES = ['queued', 'rendering', 'completed', 'failed', 'cancelled']

const selectClass =
  'h-9 rounded-md border border-input bg-transparent px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring'

export function HistoryTable() {
  const [filters, setFilters] = useState({ search: '', status: '', resolution: '', date_from: '', date_to: '' })
  const params = new URLSearchParams()
  Object.entries(filters).forEach(([key, value]) => {
    if (!value) return
    params.set(key, key.startsWith('date_') ? new Date(value).toISOString() : value)
  })
  const { data, isLoading } = useSWR<{ items: HistoryItem[] }>(SWR_KEYS.adminHistory(params), fetcher, {
    keepPreviousData: true,
  })
  const set = (key: keyof typeof filters, value: string) => setFilters((f) => ({ ...f, [key]: value }))

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input
            aria-label="Search history"
            placeholder="Search prompt, user email…"
            value={filters.search}
            onChange={(e) => set('search', e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="h-status" className="text-xs">Status</Label>
          <select id="h-status" className={selectClass} value={filters.status} onChange={(e) => set('status', e.target.value)}>
            <option value="">All</option>
            {STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="h-res" className="text-xs">Resolution</Label>
          <select id="h-res" className={selectClass} value={filters.resolution} onChange={(e) => set('resolution', e.target.value)}>
            <option value="">All</option>
            {RESOLUTIONS.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="h-from" className="text-xs">From</Label>
          <Input id="h-from" type="date" value={filters.date_from} onChange={(e) => set('date_from', e.target.value)} />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="h-to" className="text-xs">To</Label>
          <Input id="h-to" type="date" value={filters.date_to} onChange={(e) => set('date_to', e.target.value)} />
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Created</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Prompt</TableHead>
              <TableHead>Settings</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Credits</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && !data ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">Loading…</TableCell>
              </TableRow>
            ) : data?.items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">No videos match.</TableCell>
              </TableRow>
            ) : (
              data?.items.map((item) => {
                const video = item.video_url_1080p ?? item.video_url_720p
                return (
                  <TableRow key={item.id}>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                      {new Date(item.created_at).toLocaleString()}
                    </TableCell>
                    <TableCell className="max-w-44">
                      <p className="truncate text-sm">{item.user_name || '—'}</p>
                      <p className="truncate text-xs text-muted-foreground">{item.user_email}</p>
                    </TableCell>
                    <TableCell className="max-w-72">
                      {video ? (
                        <a href={video} target="_blank" rel="noreferrer" className="line-clamp-2 text-sm hover:underline">
                          {item.raw_prompt}
                        </a>
                      ) : (
                        <p className="line-clamp-2 text-sm">{item.raw_prompt}</p>
                      )}
                    </TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-xs">
                      {item.resolution} · {item.aspect_ratio} · {item.duration_seconds}s · {item.audio_mode}
                    </TableCell>
                    <TableCell>
                      <Badge variant={item.status === 'failed' ? 'destructive' : item.status === 'completed' ? 'default' : 'secondary'}>
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono tabular-nums">
                      {item.credits_charged}
                      {item.credits_refunded && <span className="ml-1 text-xs text-muted-foreground">(refunded)</span>}
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
