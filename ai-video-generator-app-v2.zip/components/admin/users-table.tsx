'use client'

import { Loader2, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import useSWR from 'swr'

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { SWR_KEYS, api, fetcher } from '@/lib/api'
import type { UserCreatePayload, UserProfile, UserRole } from '@/lib/types'

const EMPTY: UserCreatePayload = {
  name: '',
  username: '',
  email: '',
  phone: '',
  country: '',
  photo_url: '',
  password: '',
  credits: 100,
  role: 'user',
}

const TEXT_FIELDS: { key: keyof UserCreatePayload; label: string; type?: string }[] = [
  { key: 'name', label: 'Name' },
  { key: 'username', label: 'Username' },
  { key: 'email', label: 'Email', type: 'email' },
  { key: 'phone', label: 'Phone', type: 'tel' },
  { key: 'country', label: 'Country' },
  { key: 'photo_url', label: 'Photo URL', type: 'url' },
]

function UserDialog({
  user,
  open,
  onOpenChange,
  onSaved,
}: {
  user: UserProfile | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onSaved: () => void
}) {
  const [form, setForm] = useState<UserCreatePayload & { disabled: boolean }>({ ...EMPTY, disabled: false })
  const [pending, setPending] = useState(false)
  const [lastUser, setLastUser] = useState<UserProfile | null | undefined>(undefined)

  if (open && lastUser !== user) {
    setLastUser(user)
    setForm(user ? { ...EMPTY, ...user, password: '' } : { ...EMPTY, disabled: false })
  }

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }))

  async function save(event: React.FormEvent) {
    event.preventDefault()
    setPending(true)
    try {
      if (user) {
        const { password, ...rest } = form
        await api.admin.updateUser(user.id, password ? { ...rest, password } : rest)
      } else {
        const { disabled: _disabled, ...payload } = form
        await api.admin.createUser(payload)
      }
      toast.success(user ? 'User updated' : 'User created')
      onSaved()
      onOpenChange(false)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Save failed')
    } finally {
      setPending(false)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) setLastUser(undefined)
        onOpenChange(next)
      }}
    >
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{user ? 'Edit user' : 'Create user'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={save} className="grid grid-cols-2 gap-4">
          {TEXT_FIELDS.map((field) => (
            <div key={field.key} className="flex flex-col gap-2">
              <Label htmlFor={`user-${field.key}`}>{field.label}</Label>
              <Input
                id={`user-${field.key}`}
                type={field.type ?? 'text'}
                value={String(form[field.key] ?? '')}
                required={field.key === 'email'}
                onChange={(e) => set(field.key, e.target.value as never)}
              />
            </div>
          ))}
          <div className="flex flex-col gap-2">
            <Label htmlFor="user-password">{user ? 'New password' : 'Password'}</Label>
            <Input
              id="user-password"
              type="password"
              minLength={6}
              required={!user}
              placeholder={user ? 'Leave blank to keep' : ''}
              value={form.password}
              onChange={(e) => set('password', e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="user-credits">Credits</Label>
            <Input
              id="user-credits"
              type="number"
              min={0}
              value={form.credits}
              onChange={(e) => set('credits', Math.max(0, Number(e.target.value) || 0))}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <Label htmlFor="user-admin">Admin</Label>
            <Switch
              id="user-admin"
              checked={form.role === 'admin'}
              onCheckedChange={(checked) => set('role', (checked ? 'admin' : 'user') as UserRole)}
            />
          </div>
          {user && (
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <Label htmlFor="user-disabled">Disabled</Label>
              <Switch id="user-disabled" checked={form.disabled} onCheckedChange={(c) => set('disabled', c)} />
            </div>
          )}
          <DialogFooter className="col-span-2">
            <Button type="submit" disabled={pending}>
              {pending && <Loader2 className="animate-spin" aria-hidden="true" />}
              Save
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

export function UsersTable() {
  const [search, setSearch] = useState('')
  const { data, mutate, isLoading } = useSWR<{ items: UserProfile[] }>(SWR_KEYS.adminUsers(search), fetcher, {
    keepPreviousData: true,
  })
  const [editing, setEditing] = useState<UserProfile | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)

  async function remove(user: UserProfile) {
    if (!window.confirm(`Delete ${user.email}? This cannot be undone.`)) return
    try {
      await api.admin.deleteUser(user.id)
      toast.success('User deleted')
      mutate()
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Delete failed')
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input
            aria-label="Search users"
            placeholder="Search name, email, username…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button
          className="ml-auto"
          onClick={() => {
            setEditing(null)
            setDialogOpen(true)
          }}
        >
          <Plus aria-hidden="true" /> New user
        </Button>
      </div>

      <div className="overflow-hidden rounded-xl border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Country</TableHead>
              <TableHead className="text-right">Credits</TableHead>
              <TableHead>Role</TableHead>
              <TableHead className="w-24">
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && !data ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                  Loading…
                </TableCell>
              </TableRow>
            ) : data?.items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                  No users found.
                </TableCell>
              </TableRow>
            ) : (
              data?.items.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="size-8">
                        {user.photo_url && <AvatarImage src={user.photo_url || '/placeholder.svg'} alt="" />}
                        <AvatarFallback className="text-xs">{(user.name || user.email).slice(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="truncate font-medium">{user.name || user.username || '—'}</p>
                        <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{user.phone || '—'}</TableCell>
                  <TableCell className="text-muted-foreground">{user.country || '—'}</TableCell>
                  <TableCell className="text-right font-mono tabular-nums">{user.credits}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>{user.role}</Badge>
                      {user.disabled && <Badge variant="destructive">disabled</Badge>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Edit ${user.email}`}
                        onClick={() => {
                          setEditing(user)
                          setDialogOpen(true)
                        }}
                      >
                        <Pencil aria-hidden="true" />
                      </Button>
                      <Button variant="ghost" size="icon-sm" aria-label={`Delete ${user.email}`} onClick={() => remove(user)}>
                        <Trash2 aria-hidden="true" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <UserDialog user={editing} open={dialogOpen} onOpenChange={setDialogOpen} onSaved={() => mutate()} />
    </div>
  )
}
