'use client'

import { Bar, BarChart, CartesianGrid, XAxis } from 'recharts'
import useSWR from 'swr'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { Skeleton } from '@/components/ui/skeleton'
import { SWR_KEYS, fetcher } from '@/lib/api'
import type { AdminStats } from '@/lib/types'

const chartConfig = {
  videos: { label: 'Videos', color: 'var(--primary)' },
  credits: { label: 'Credits', color: 'var(--accent-brand)' },
} satisfies ChartConfig

function Split({ title, data }: { title: string; data: Record<string, number> }) {
  const total = Object.values(data).reduce((sum, n) => sum + n, 0) || 1
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {Object.entries(data).length === 0 && <p className="text-sm text-muted-foreground">No data yet.</p>}
        {Object.entries(data).map(([key, value]) => (
          <div key={key} className="flex flex-col gap-1">
            <div className="flex justify-between text-xs">
              <span>{key}</span>
              <span className="font-mono tabular-nums text-muted-foreground">{value}</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-primary" style={{ width: `${(value / total) * 100}%` }} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

export function Overview() {
  const { data, error } = useSWR<AdminStats>(SWR_KEYS.adminStats, fetcher)

  if (error) return <p className="text-sm text-destructive">{error.message}</p>
  if (!data) return <Skeleton className="h-80 rounded-xl" />

  const stats = [
    { label: 'Users', value: data.total_users },
    { label: 'Videos', value: data.total_videos },
    { label: 'Completed', value: data.completed_videos },
    { label: 'Failed', value: data.failed_videos },
    { label: 'Active jobs', value: data.active_jobs },
    { label: 'Credits used', value: data.credits_consumed },
  ]

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="gap-1 py-4">
            <CardContent className="px-4">
              <p className="text-xs text-muted-foreground">{stat.label}</p>
              <p className="mt-1 font-mono text-2xl font-semibold tabular-nums">{stat.value.toLocaleString()}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm">Daily activity</CardTitle>
            <CardDescription>Videos created and credits spent, last 14 days</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-64 w-full">
              <BarChart data={data.daily}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="date" tickLine={false} axisLine={false} tickFormatter={(d: string) => d.slice(5)} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="videos" fill="var(--color-videos)" radius={4} />
                <Bar dataKey="credits" fill="var(--color-credits)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <div className="flex flex-col gap-4">
          <Split title="By resolution" data={data.resolution_split} />
          <Split title="By audio mode" data={data.audio_split} />
        </div>
      </div>
    </div>
  )
}
