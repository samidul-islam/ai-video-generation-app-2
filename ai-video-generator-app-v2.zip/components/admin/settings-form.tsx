'use client'

import { Loader2 } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import useSWR, { useSWRConfig } from 'swr'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { SWR_KEYS, api, fetcher } from '@/lib/api'
import type { AppSettings } from '@/lib/types'

type Section = keyof AppSettings

const SECTIONS: { key: Section; title: string; description: string }[] = [
  { key: 'meta', title: 'App', description: 'Name, branding and global switches.' },
  { key: 'gemini', title: 'Gemini', description: 'Prompt parsing model.' },
  { key: 'google_tts', title: 'Google TTS', description: 'Chirp HQ Bengali voice.' },
  { key: 'elevenlabs', title: 'ElevenLabs', description: 'Alternative HQ voice engine.' },
  { key: 'runpod', title: 'RunPod', description: 'GPU video rendering endpoint.' },
  { key: 'firebase', title: 'Firebase', description: 'Web client config (auth + storage).' },
]

const isSecret = (field: string) => /api_key|secret/.test(field)
const labelFor = (field: string) => field.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())

function Editor({ initial }: { initial: AppSettings }) {
  const { mutate } = useSWRConfig()
  const [form, setForm] = useState(initial)
  const [pending, setPending] = useState(false)

  function setField(section: Section, field: string, value: unknown) {
    setForm((f) => ({ ...f, [section]: { ...f[section], [field]: value } }))
  }

  async function save(event: React.FormEvent) {
    event.preventDefault()
    setPending(true)
    try {
      const saved = await api.admin.saveSettings(form)
      setForm(saved)
      mutate(SWR_KEYS.adminSettings, saved, false)
      mutate(SWR_KEYS.appConfig)
      toast.success('Settings saved')
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Save failed')
    } finally {
      setPending(false)
    }
  }

  return (
    <form onSubmit={save} className="flex flex-col gap-4">
      <div className="grid gap-4 lg:grid-cols-2">
        {SECTIONS.map((section) => (
          <Card key={section.key}>
            <CardHeader>
              <CardTitle className="text-base">{section.title}</CardTitle>
              <CardDescription>{section.description}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {Object.entries(form[section.key]).map(([field, value]) => {
                const id = `set-${section.key}-${field}`
                if (typeof value === 'boolean') {
                  return (
                    <div key={field} className="flex items-center justify-between rounded-lg border border-border p-3">
                      <Label htmlFor={id}>{labelFor(field)}</Label>
                      <Switch id={id} checked={value} onCheckedChange={(c) => setField(section.key, field, c)} />
                    </div>
                  )
                }
                return (
                  <div key={field} className="flex flex-col gap-2">
                    <Label htmlFor={id}>{labelFor(field)}</Label>
                    <Input
                      id={id}
                      type={typeof value === 'number' ? 'number' : isSecret(field) ? 'password' : 'text'}
                      step="any"
                      autoComplete="off"
                      value={String(value)}
                      placeholder={isSecret(field) ? 'Not set' : undefined}
                      onChange={(e) =>
                        setField(section.key, field, typeof value === 'number' ? Number(e.target.value) : e.target.value)
                      }
                    />
                  </div>
                )
              })}
            </CardContent>
          </Card>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">
        Secrets are shown masked. Leave a masked value untouched to keep the stored key.
      </p>
      <div className="flex justify-end">
        <Button type="submit" disabled={pending}>
          {pending && <Loader2 className="animate-spin" aria-hidden="true" />}
          Save settings
        </Button>
      </div>
    </form>
  )
}

export function SettingsForm() {
  const { data } = useSWR<AppSettings>(SWR_KEYS.adminSettings, fetcher)
  return data ? <Editor initial={data} /> : <Skeleton className="h-96 rounded-xl" />
}
