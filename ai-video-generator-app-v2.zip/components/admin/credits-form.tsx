'use client'

import { Loader2 } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import useSWR, { useSWRConfig } from 'swr'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { SWR_KEYS, api, fetcher } from '@/lib/api'
import { videoCost } from '@/lib/pricing'
import type { CreditConfig } from '@/lib/types'

const FIELDS: { key: keyof CreditConfig; label: string; hint: string }[] = [
  { key: 'per_second_360p', label: '360p', hint: 'Credits per second' },
  { key: 'per_second_540p', label: '540p', hint: 'Credits per second' },
  { key: 'per_second_720p', label: '720p', hint: 'Credits per second' },
  { key: 'per_second_1080p', label: '1080p', hint: 'Credits per second' },
  { key: 'native_audio_charge', label: 'Native audio', hint: 'Flat charge per video' },
  { key: 'starting_credits', label: 'Signup bonus', hint: 'Credits for new accounts' },
]

function Editor({ initial }: { initial: CreditConfig }) {
  const { mutate } = useSWRConfig()
  const [form, setForm] = useState(initial)
  const [pending, setPending] = useState(false)

  async function save(event: React.FormEvent) {
    event.preventDefault()
    setPending(true)
    try {
      await api.admin.saveCredits(form)
      mutate(SWR_KEYS.adminCredits)
      mutate(SWR_KEYS.appConfig)
      toast.success('Pricing saved')
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Save failed')
    } finally {
      setPending(false)
    }
  }

  return (
    <form onSubmit={save}>
      <Card>
        <CardHeader>
          <CardTitle>Credit pricing</CardTitle>
          <CardDescription>
            Example: a 5s 720p clip with native audio costs{' '}
            <span className="font-mono text-foreground">{videoCost(form, '720p', 5, true)}</span> credits.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FIELDS.map((field) => (
            <div key={field.key} className="flex flex-col gap-2">
              <Label htmlFor={`cr-${field.key}`}>{field.label}</Label>
              <Input
                id={`cr-${field.key}`}
                type="number"
                min={0}
                step="0.1"
                value={form[field.key]}
                onChange={(e) => setForm((f) => ({ ...f, [field.key]: Math.max(0, Number(e.target.value) || 0) }))}
              />
              <p className="text-xs text-muted-foreground">{field.hint}</p>
            </div>
          ))}
        </CardContent>
        <CardFooter className="justify-end">
          <Button type="submit" disabled={pending}>
            {pending && <Loader2 className="animate-spin" aria-hidden="true" />}
            Save pricing
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}

export function CreditsForm() {
  const { data } = useSWR<CreditConfig>(SWR_KEYS.adminCredits, fetcher)
  return data ? <Editor initial={data} /> : <Skeleton className="h-72 rounded-xl" />
}
