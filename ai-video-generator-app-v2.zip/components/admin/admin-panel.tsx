'use client'

import { Coins, History, LayoutDashboard, Palette, Settings, Users } from 'lucide-react'

import { CreditsForm } from '@/components/admin/credits-form'
import { HistoryTable } from '@/components/admin/history-table'
import { Overview } from '@/components/admin/overview'
import { SettingsForm } from '@/components/admin/settings-form'
import { ThemeForm } from '@/components/admin/theme-form'
import { UsersTable } from '@/components/admin/users-table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const TABS = [
  { value: 'overview', label: 'Overview', icon: LayoutDashboard, panel: Overview },
  { value: 'users', label: 'Users', icon: Users, panel: UsersTable },
  { value: 'history', label: 'History', icon: History, panel: HistoryTable },
  { value: 'credits', label: 'Credits', icon: Coins, panel: CreditsForm },
  { value: 'settings', label: 'Settings', icon: Settings, panel: SettingsForm },
  { value: 'theme', label: 'Theme', icon: Palette, panel: ThemeForm },
]

export function AdminPanel() {
  return (
    <Tabs defaultValue="overview" className="flex flex-col gap-6">
      <TabsList className="h-auto flex-wrap justify-start">
        {TABS.map(({ value, label, icon: Icon }) => (
          <TabsTrigger key={value} value={value} className="gap-2">
            <Icon aria-hidden="true" />
            {label}
          </TabsTrigger>
        ))}
      </TabsList>
      {TABS.map(({ value, panel: Panel }) => (
        <TabsContent key={value} value={value}>
          <Panel />
        </TabsContent>
      ))}
    </Tabs>
  )
}
