'use client'

import { Loader2, RotateCcw } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import useSWR, { useSWRConfig } from 'swr'

import { DEFAULT_THEME, themeToCss } from '@/components/app-config-provider'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { SWR_KEYS, api, fetcher } from '@/lib/api'
import type { ThemeConfig } from '@/lib/types'

const COLORS: { key: keyof ThemeConfig; label: string }[] = [
  { key: 'primary', label: 'Primary' },
  { key: 'accent', label: 'Accent' },
  { key: 'background', label: 'Background' },
  { key: 'surface', label: 'Surface' },
  { key: 'foreground', label: 'Text' },
]

const COPY: { key: keyof ThemeConfig; label: string }[] = [
  { key: 'hero_title', label: 'Hero title' },
  { key: 'hero_subtitle', label: 'Hero subtitle' },
  { key: 'create_label', label: 'Create button label' },
  { key: 'prompt_placeholder', label: 'Prompt placeholder' },
]

function Editor({ initial }: { initial: ThemeConfig }) {
  const { mutate } = useSWRConfig()
  const [form, setForm] = useState(initial)
  const [pending, setPending] = useState(false)
  const set = <K extends keyof ThemeConfig>(key: K, value: ThemeConfig[K]) => setForm((f) => ({ ...f, [key]: value }))

  async function save(event: React.FormEvent) {
    event.preventDefault()
    setPending(true)
    try {
      await api.admin.saveTheme(form)
      mutate(SWR_KEYS.adminTheme)
      mutate(SWR_KEYS.appConfig)
      toast.success('Theme applied for everyone')
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Save failed')
    } finally {
      setPending(false)
    }
  }

  return (
    <form onSubmit={save} className="grid gap-4 lg:grid-cols-[1fr_380px]">
      <div className="flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Colors</CardTitle>
            <CardDescription>Applied app-wide as CSS variables.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-3">
            {COLORS.map(({ key, label }) => (
              <div key={key} className="flex flex-col gap-2">
                <Label htmlFor={`th-${key}`}>{label}</Label>
                <div className="flex items-center gap-2">
                  <input
                    id={`th-${key}`}
                    type="color"
                    value={String(form[key])}
                    onChange={(e) => set(key, e.target.value as never)}
                    className="size-9 shrink-0 cursor-pointer rounded-md border border-border bg-transparent"
                  />
                  <Input
                    aria-label={`${label} hex`}
                    value={String(form[key])}
                    onChange={(e) => set(key, e.target.value as never)}
                    className="font-mono text-xs"
                  />
                </div>
              </div>
            ))}
            <div className="flex flex-col gap-2">
              <Label htmlFor="th-radius">Corner radius (rem)</Label>
              <Input
                id="th-radius"
                type="number"
                min={0}
                max={2}
                step="0.05"
                value={form.radius}
                onChange={(e) => set('radius', Number(e.target.value))}
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="th-font">Font</Label>
              <select
                id="th-font"
                value={form.font}
                onChange={(e) => set('font', e.target.value as ThemeConfig['font'])}
                className="h-9 rounded-md border border-input bg-transparent px-3 text-sm"
              >
                <option value="geist">Geist</option>
                <option value="inter">Inter</option>
                <option value="system">System</option>
              </select>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Copy</CardTitle>
            <CardDescription>Text shown on the create page.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {COPY.map(({ key, label }) => (
              <div key={key} className="flex flex-col gap-2">
                <Label htmlFor={`th-${key}`}>{label}</Label>
                <Input id={`th-${key}`} value={String(form[key])} onChange={(e) => set(key, e.target.value as never)} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4">
        <div
          style={themeToCss(form) as React.CSSProperties}
          className="flex flex-col gap-4 overflow-hidden rounded-xl border border-border bg-background p-5 text-foreground"
          aria-label="Theme preview"
        >
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Preview</p>
          <h3 className="text-balance text-xl font-semibold">{form.hero_title}</h3>
          <p className="text-sm text-muted-foreground">{form.hero_subtitle}</p>
          <div className="rounded-2xl border border-border bg-card p-3">
            <p className="text-sm text-muted-foreground">{form.prompt_placeholder}</p>
            <div className="mt-3 flex justify-end">
              <span className="rounded-full bg-primary px-4 py-1.5 text-sm text-primary-foreground">{form.create_label}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => setForm(DEFAULT_THEME)}>
            <RotateCcw aria-hidden="true" /> Reset
          </Button>
          <Button type="submit" disabled={pending} className="flex-1">
            {pending && <Loader2 className="animate-spin" aria-hidden="true" />}
            Save theme
          </Button>
        </div>
      </div>
    </form>
  )
}

export function ThemeForm() {
  const { data } = useSWR<ThemeConfig>(SWR_KEYS.adminTheme, fetcher)
  return data ? <Editor initial={data} /> : <Skeleton className="h-96 rounded-xl" />
}
