'use client'

import {
  createUserWithEmailAndPassword,
  onIdTokenChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
  type User,
} from 'firebase/auth'
import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import useSWR, { useSWRConfig } from 'swr'

import { SWR_KEYS, fetcher, setTokenGetter } from '@/lib/api'
import { getFirebaseAuth, isFirebaseConfigured } from '@/lib/firebase'
import type { MeResponse } from '@/lib/types'

interface AuthContextValue {
  /** Firebase user, or null. When Firebase isn't configured the backend's dev user is used. */
  user: User | null
  ready: boolean
  signedIn: boolean
  firebaseEnabled: boolean
  me: MeResponse | undefined
  signIn: (email: string, password: string) => Promise<void>
  signUp: (name: string, email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [ready, setReady] = useState(!isFirebaseConfigured)
  const { mutate } = useSWRConfig()

  useEffect(() => {
    const auth = getFirebaseAuth()
    if (!auth) return
    setTokenGetter(async () => auth.currentUser?.getIdToken() ?? null)
    return onIdTokenChanged(auth, (next) => {
      setUser(next)
      setReady(true)
    })
  }, [])

  const signedIn = !isFirebaseConfigured || Boolean(user)
  const { data: me } = useSWR<MeResponse>(ready && signedIn ? [SWR_KEYS.me, user?.uid] : null, ([key]: [string]) =>
    fetcher<MeResponse>(key),
  )

  const value = useMemo<AuthContextValue>(() => {
    const requireAuth = () => {
      const auth = getFirebaseAuth()
      if (!auth) throw new Error('Firebase is not configured.')
      return auth
    }
    return {
      user,
      ready,
      signedIn,
      firebaseEnabled: isFirebaseConfigured,
      me,
      signIn: async (email, password) => {
        await signInWithEmailAndPassword(requireAuth(), email, password)
      },
      signUp: async (name, email, password) => {
        const credential = await createUserWithEmailAndPassword(requireAuth(), email, password)
        if (name) await updateProfile(credential.user, { displayName: name })
        await credential.user.getIdToken(true)
      },
      signOut: async () => {
        await firebaseSignOut(requireAuth())
        await mutate(() => true, undefined, { revalidate: false })
      },
    }
  }, [user, ready, signedIn, me, mutate])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
