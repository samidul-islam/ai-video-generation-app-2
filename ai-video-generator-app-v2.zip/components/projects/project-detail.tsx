'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import useSWR from 'swr'

import { DeleteProjectButton } from '@/components/projects/delete-project-button'
import { RenderProgress } from '@/components/render-progress'
import { Badge } from '@/components/ui/badge'
import { buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { VideoPlayer } from '@/components/video-player'
import { SWR_KEYS, fetcher } from '@/lib/api'
import { STATUS_LABELS, formatDate, statusVariant } from '@/lib/status'
import type { Project } from '@/lib/types'

export function ProjectDetail({ projectId }: { projectId: string }) {
  const router = useRouter()
  const { data: project, error, isLoading } = useSWR<Project>(SWR_KEYS.project(projectId), fetcher)

  if (isLoading) return <Skeleton className="aspect-video w-full rounded-xl" />

  if (error || !project) {
    return (
      <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-6">
        <p className="font-medium">Project not found</p>
        <p className="mt-1 text-sm text-muted-foreground">{error?.message ?? 'It may have been deleted.'}</p>
      </div>
    )
  }

  const parsed = project.parsed_prompt

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex flex-col gap-2">
          <Link href="/projects" className={buttonVariants({ variant: 'ghost', size: 'sm', className: '-ml-2 w-fit' })}>
            <ArrowLeft aria-hidden="true" />
            Projects
          </Link>
          <h1 className="text-balance text-2xl font-semibold tracking-tight md:text-3xl">{project.title}</h1>
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <Badge variant={statusVariant(project.status)}>{STATUS_LABELS[project.status]}</Badge>
            <time dateTime={project.created_at}>{formatDate(project.created_at)}</time>
          </div>
        </div>
        <DeleteProjectButton
          projectId={project.id}
          title={project.title}
          onDeleted={() => router.push('/projects')}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div>
          {project.status === 'completed' ? (
            <VideoPlayer project={project} />
          ) : (
            <RenderProgress key={project.status} projectId={project.id} initialProject={project} />
          )}
        </div>

        <dl className="flex flex-col gap-4 rounded-xl border border-border bg-card p-4 text-sm md:p-5">
          <Detail label="Original prompt" value={project.raw_prompt} />
          {parsed && (
            <>
              <Detail label="Visual prompt" value={parsed.visual_prompt} />
              <Detail label="Dialogue" value={parsed.dialogue} lang="bn" />
              <Detail label="Sound effects" value={parsed.sound_effects} />
            </>
          )}
          <div className="grid grid-cols-3 gap-3 border-t border-border pt-4">
            <Detail label="Audio" value={project.audio_mode === 'hq_bengali' ? 'HQ Bengali' : 'Native'} />
            <Detail label="Resolution" value={project.resolution} />
            <Detail label="Credits" value={String(project.credits_charged)} />
          </div>
          {project.audio_url && (
            <div className="flex flex-col gap-1.5">
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">Voice track</dt>
              <dd>
                <audio controls src={project.audio_url} className="w-full" />
              </dd>
            </div>
          )}
        </dl>
      </div>
    </div>
  )
}

function Detail({ label, value, lang }: { label: string; value: string; lang?: string }) {
  if (!value) return null
  return (
    <div className="flex flex-col gap-1">
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd lang={lang} className="whitespace-pre-wrap text-pretty leading-relaxed">
        {value}
      </dd>
    </div>
  )
}
