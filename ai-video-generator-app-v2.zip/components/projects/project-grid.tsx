'use client'

import Link from 'next/link'
import { Film, Mic, Plus, Volume2 } from 'lucide-react'
import useSWR from 'swr'

import { DeleteProjectButton } from '@/components/projects/delete-project-button'
import { Badge } from '@/components/ui/badge'
import { buttonVariants } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { SWR_KEYS, fetcher } from '@/lib/api'
import { STATUS_LABELS, formatDate, statusVariant } from '@/lib/status'
import type { Project, ProjectList } from '@/lib/types'

export function ProjectGrid() {
  const { data, error, isLoading } = useSWR<ProjectList>(SWR_KEYS.projects, fetcher, {
    refreshInterval: (latest) =>
      latest?.items.some((project) => project.status === 'queued' || project.status === 'rendering') ? 5000 : 0,
  })

  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }, (_, index) => (
          <Skeleton key={index} className="aspect-[4/3] rounded-xl" />
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-6">
        <p className="font-medium">Could not load your projects</p>
        <p className="mt-1 text-sm text-muted-foreground">{error.message}</p>
      </div>
    )
  }

  if (!data?.items.length) {
    return (
      <div className="flex flex-col items-center gap-4 rounded-xl border border-dashed border-border px-6 py-16 text-center">
        <Film className="size-8 text-muted-foreground" aria-hidden="true" />
        <div className="flex flex-col gap-1">
          <p className="font-medium">No projects yet</p>
          <p className="text-sm text-muted-foreground">Your rendered scenes will be listed here.</p>
        </div>
        <Link href="/" className={buttonVariants()}>
          <Plus aria-hidden="true" />
          New scene
        </Link>
      </div>
    )
  }

  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {data.items.map((project) => (
        <ProjectCard key={project.id} project={project} />
      ))}
    </ul>
  )
}

function ProjectCard({ project }: { project: Project }) {
  const AudioIcon = project.audio_mode === 'hq_bengali' ? Mic : Volume2
  return (
    <li className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/50">
      <div className="relative aspect-video bg-secondary">
        {project.thumbnail_url ? (
          <img src={project.thumbnail_url} alt="" className="size-full object-cover" />
        ) : (
          <div className="flex size-full items-center justify-center">
            <Film className="size-6 text-muted-foreground" aria-hidden="true" />
          </div>
        )}
        <Badge variant={statusVariant(project.status)} className="absolute left-2 top-2">
          {project.status === 'rendering' ? `${STATUS_LABELS.rendering} ${project.progress}%` : STATUS_LABELS[project.status]}
        </Badge>
      </div>
      <div className="flex items-start justify-between gap-2 p-3">
        <div className="flex min-w-0 flex-col gap-1">
          <Link
            href={`/projects/${project.id}`}
            className="truncate font-medium after:absolute after:inset-0 focus-visible:outline-none"
          >
            {project.title}
          </Link>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <AudioIcon className="size-3" aria-hidden="true" />
            <span>{project.audio_mode === 'hq_bengali' ? 'HQ Bengali' : 'Native'}</span>
            <span aria-hidden="true">·</span>
            <span>{project.resolution}</span>
            <span aria-hidden="true">·</span>
            <time dateTime={project.created_at}>{formatDate(project.created_at)}</time>
          </p>
        </div>
        <div className="relative z-10">
          <DeleteProjectButton projectId={project.id} title={project.title} />
        </div>
      </div>
    </li>
  )
}
