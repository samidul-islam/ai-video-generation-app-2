import { BrandMark } from '@/components/brand-mark'
import { CreditsBadge } from '@/components/credits-badge'
import { HeaderNav } from '@/components/header-nav'
import { UserMenu } from '@/components/user-menu'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 md:px-6">
        <BrandMark />
        <HeaderNav />
        <div className="ml-auto flex items-center gap-3">
          <CreditsBadge />
          <UserMenu />
        </div>
      </div>
    </header>
  )
}
