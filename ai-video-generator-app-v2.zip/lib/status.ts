import type { ProjectStatus } from '@/lib/types'

export const STATUS_LABELS: Record<ProjectStatus, string> = {
  draft: 'Draft',
  queued: 'Queued',
  rendering: 'Rendering',
  completed: 'Ready',
  failed: 'Failed',
  cancelled: 'Cancelled',
}

export function statusVariant(status: ProjectStatus): 'default' | 'secondary' | 'destructive' | 'outline' {
  if (status === 'completed') return 'default'
  if (status === 'failed' || status === 'cancelled') return 'destructive'
  if (status === 'draft') return 'outline'
  return 'secondary'
}

export function formatDate(iso: string) {
  return new Intl.DateTimeFormat('en', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso))
}
