import type { AspectRatio, CreditConfig, Resolution } from '@/lib/types'

export const RESOLUTIONS: Resolution[] = ['360p', '540p', '720p', '1080p']
export const ASPECT_RATIOS: AspectRatio[] = ['16:9', '4:3', '1:1', '3:4', '9:16', '21:9', '3:2', '2:3']
export const DURATIONS = Array.from({ length: 20 }, (_, i) => i + 1)

export const DEFAULT_CREDIT_CONFIG: CreditConfig = {
  per_second_360p: 1,
  per_second_540p: 2,
  per_second_720p: 3,
  per_second_1080p: 5,
  native_audio_charge: 5,
  starting_credits: 100,
}

// Mirrors backend/app/services/pricing.py so the Create button shows the exact charge.
export function videoCost(config: CreditConfig, resolution: Resolution, durationSeconds: number, nativeAudio: boolean) {
  const perSecond = {
    '360p': config.per_second_360p,
    '540p': config.per_second_540p,
    '720p': config.per_second_720p,
    '1080p': config.per_second_1080p,
  }[resolution]
  const total = perSecond * durationSeconds + (nativeAudio ? config.native_audio_charge : 0)
  return Math.max(1, Math.ceil(total))
}

export function aspectBox(ratio: AspectRatio, max = 16) {
  const [w, h] = ratio.split(':').map(Number)
  const scale = max / Math.max(w, h)
  return { width: Math.round(w * scale), height: Math.round(h * scale) }
}
