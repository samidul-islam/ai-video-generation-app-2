export type AudioMode = 'native' | 'hq_bengali'
export type TtsProvider = 'google_chirp' | 'elevenlabs'
export type Resolution = '360p' | '540p' | '720p' | '1080p'
export type AspectRatio = '16:9' | '4:3' | '1:1' | '3:4' | '9:16' | '21:9' | '3:2' | '2:3'
export type GenerationMode = 'text-to-video' | 'image-to-video'
export type ProjectStatus = 'draft' | 'queued' | 'rendering' | 'completed' | 'failed' | 'cancelled'

export const TERMINAL_STATUSES: ProjectStatus[] = ['completed', 'failed', 'cancelled']

export interface ParsedPrompt {
  visual_prompt: string
  character_mapping: string
  dialogue: string
  sound_effects: string
  full_minimax_prompt: string
  detected_language?: string | null
}

export interface Project {
  id: string
  user_id: string
  title: string
  mode: GenerationMode
  raw_prompt: string
  parsed_prompt: ParsedPrompt | null
  audio_mode: AudioMode
  tts_provider: TtsProvider | null
  audio_url: string | null
  reference_image_urls: string[]
  resolution: Resolution
  aspect_ratio: AspectRatio
  duration_seconds: number
  status: ProjectStatus
  progress: number
  status_message: string | null
  runpod_job_id: string | null
  video_url_720p: string | null
  video_url_1080p: string | null
  thumbnail_url: string | null
  error: string | null
  credits_charged: number
  credits_refunded: boolean
  expires_at: string | null
  created_at: string
  updated_at: string
}

export interface ProjectList {
  items: Project[]
  total: number | null
}

export interface JobEvent {
  project_id: string
  status: ProjectStatus
  progress: number
  message: string | null
  project: Project
}

export interface GenerateVideoPayload {
  title?: string
  mode: GenerationMode
  raw_prompt: string
  parsed_prompt?: ParsedPrompt | null
  audio_mode: AudioMode
  tts_provider?: TtsProvider | null
  audio_url?: string | null
  reference_image_urls: string[]
  resolution: Resolution
  aspect_ratio: AspectRatio
  duration_seconds: number
}

export interface GenerateVideoResponse {
  project_id: string
  job_id: string
  status: ProjectStatus
  credits_charged: number
  balance: number
}

export interface CreditsResponse {
  balance: number
  video_cost: number
  audio_cost: number
}

export interface CreditConfig {
  per_second_360p: number
  per_second_540p: number
  per_second_720p: number
  per_second_1080p: number
  native_audio_charge: number
  starting_credits: number
}

export interface AppMeta {
  name: string
  tagline: string
  description: string
  logo_url: string
  favicon_url: string
  support_email: string
  maintenance_mode: boolean
  allow_signups: boolean
  video_retention_hours: number
}

export interface AppSettings {
  meta: AppMeta
  gemini: { api_key: string; model: string; temperature: number }
  elevenlabs: { api_key: string; voice_id: string; model_id: string }
  google_tts: { api_key: string; language: string; voice: string }
  runpod: { api_key: string; endpoint_id: string; webhook_secret: string }
  firebase: { api_key: string; auth_domain: string; project_id: string; storage_bucket: string; app_id: string }
}

export interface ThemeConfig {
  primary: string
  accent: string
  background: string
  surface: string
  foreground: string
  radius: number
  font: 'geist' | 'inter' | 'system'
  hero_title: string
  hero_subtitle: string
  create_label: string
  prompt_placeholder: string
}

export interface PublicConfig {
  meta: AppMeta
  credits: CreditConfig
  theme: ThemeConfig
}

export type UserRole = 'user' | 'admin'

export interface UserProfile {
  id: string
  name: string
  username: string
  email: string
  phone: string
  country: string
  photo_url: string
  credits: number
  role: UserRole
  disabled: boolean
  created_at: string | null
}

export interface UserCreatePayload {
  name: string
  username: string
  email: string
  phone: string
  country: string
  photo_url: string
  password: string
  credits: number
  role: UserRole
}

export type UserUpdatePayload = Partial<UserCreatePayload> & { disabled?: boolean }

export interface MeResponse {
  profile: UserProfile
  is_admin: boolean
}

export interface HistoryItem extends Project {
  user_email: string
  user_name: string
}

export interface AdminStats {
  total_users: number
  total_videos: number
  completed_videos: number
  failed_videos: number
  active_jobs: number
  credits_consumed: number
  daily: { date: string; videos: number; credits: number }[]
  resolution_split: Record<string, number>
  audio_split: Record<string, number>
}
