import type {
  AdminStats,
  AppSettings,
  CreditConfig,
  CreditsResponse,
  GenerateVideoPayload,
  GenerateVideoResponse,
  HistoryItem,
  JobEvent,
  MeResponse,
  ParsedPrompt,
  Project,
  ThemeConfig,
  TtsProvider,
  UserCreatePayload,
  UserProfile,
  UserUpdatePayload,
} from '@/lib/types'

export const API_URL = (process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000').replace(/\/$/, '')

export const SWR_KEYS = {
  health: '/health',
  me: '/api/v1/me',
  appConfig: '/api/v1/app-config',
  credits: '/api/v1/me/credits',
  projects: '/api/v1/projects?limit=50',
  project: (id: string) => `/api/v1/projects/${id}`,
  adminStats: '/api/v1/admin/stats',
  adminUsers: (search = '') => `/api/v1/admin/users?search=${encodeURIComponent(search)}`,
  adminHistory: (params: URLSearchParams) => `/api/v1/admin/history?${params.toString()}`,
  adminCredits: '/api/v1/admin/credits',
  adminSettings: '/api/v1/admin/settings',
  adminTheme: '/api/v1/admin/theme',
} as const

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message)
  }
}

type TokenGetter = () => Promise<string | null>
let getToken: TokenGetter = async () => null

export function setTokenGetter(getter: TokenGetter) {
  getToken = getter
}

function extractDetail(body: unknown): string | undefined {
  if (!body || typeof body !== 'object' || !('detail' in body)) return undefined
  const detail = (body as { detail: unknown }).detail
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail) && detail[0]?.msg) return String(detail[0].msg)
  return undefined
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await getToken()
  const headers = new Headers(init.headers)
  if (token) headers.set('Authorization', `Bearer ${token}`)

  let response: Response
  try {
    response = await fetch(`${API_URL}${path}`, { ...init, headers })
  } catch {
    throw new ApiError(`Can't reach the API at ${API_URL}.`, 0)
  }
  if (!response.ok) {
    const body = await response.json().catch(() => null)
    throw new ApiError(extractDetail(body) ?? response.statusText, response.status)
  }
  if (response.status === 204) return undefined as T
  return response.json() as Promise<T>
}

const send = (method: string, body: unknown): RequestInit => ({
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
})
const json = (body: unknown) => send('POST', body)

export const fetcher = <T,>(path: string) => request<T>(path)

export const api = {
  parsePrompt: (text: string, characterCount: number) =>
    request<ParsedPrompt>('/api/v1/parse-prompt', json({ text, character_count: characterCount })),

  uploadReferences: (files: File[]) => {
    const form = new FormData()
    files.forEach((file) => form.append('files', file))
    return request<{ urls: string[] }>('/api/v1/uploads', { method: 'POST', body: form })
  },

  generateAudio: (text: string, provider: TtsProvider) =>
    request<{ audio_url: string; provider: TtsProvider; content_type: string }>(
      '/api/v1/generate-audio',
      json({ text, provider }),
    ),

  generateVideo: (payload: GenerateVideoPayload) =>
    request<GenerateVideoResponse>('/api/v1/generate-video', json(payload)),

  cancelJob: (projectId: string) =>
    request<JobEvent>(`/api/v1/generate-video/${projectId}/cancel`, { method: 'POST' }),

  deleteProject: (projectId: string) => request<void>(`/api/v1/projects/${projectId}`, { method: 'DELETE' }),

  getCredits: () => request<CreditsResponse>(SWR_KEYS.credits),
  getProject: (projectId: string) => request<Project>(SWR_KEYS.project(projectId)),
  me: () => request<MeResponse>(SWR_KEYS.me),

  admin: {
    createUser: (body: UserCreatePayload) => request<UserProfile>('/api/v1/admin/users', json(body)),
    updateUser: (id: string, body: UserUpdatePayload) =>
      request<UserProfile>(`/api/v1/admin/users/${id}`, send('PATCH', body)),
    deleteUser: (id: string) => request<void>(`/api/v1/admin/users/${id}`, { method: 'DELETE' }),
    saveCredits: (body: CreditConfig) => request<CreditConfig>(SWR_KEYS.adminCredits, send('PUT', body)),
    saveSettings: (body: AppSettings) => request<AppSettings>(SWR_KEYS.adminSettings, send('PUT', body)),
    saveTheme: (body: ThemeConfig) => request<ThemeConfig>(SWR_KEYS.adminTheme, send('PUT', body)),
  },
}

export type { AdminStats, HistoryItem }

export async function jobEventsUrl(projectId: string) {
  const token = await getToken()
  const query = token ? `?access_token=${encodeURIComponent(token)}` : ''
  return `${API_URL}/api/v1/generate-video/${projectId}/events${query}`
}
