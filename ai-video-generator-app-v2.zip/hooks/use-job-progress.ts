'use client'

import { useEffect, useEffectEvent, useState } from 'react'
import { useSWRConfig } from 'swr'

import { SWR_KEYS, jobEventsUrl } from '@/lib/api'
import type { JobEvent } from '@/lib/types'

export function useJobProgress(projectId: string | null) {
  const { mutate } = useSWRConfig()
  const [event, setEvent] = useState<JobEvent | null>(null)
  const [connectionLost, setConnectionLost] = useState(false)

  const handleFinished = useEffectEvent((finalEvent: JobEvent | null) => {
    mutate(SWR_KEYS.credits)
    mutate(SWR_KEYS.projects)
    if (finalEvent) mutate(SWR_KEYS.project(finalEvent.project_id), finalEvent.project, false)
  })

  useEffect(() => {
    if (!projectId) return
    setEvent(null)
    setConnectionLost(false)

    let latest: JobEvent | null = null
    let source: EventSource | null = null
    let disposed = false

    jobEventsUrl(projectId).then((url) => {
      if (disposed) return
      const stream = new EventSource(url)
      source = stream
      stream.addEventListener('progress', (message) => {
        latest = JSON.parse((message as MessageEvent<string>).data) as JobEvent
        setEvent(latest)
        setConnectionLost(false)
      })
      stream.addEventListener('done', () => {
        stream.close()
        handleFinished(latest)
      })
      stream.onerror = () => {
        setConnectionLost(stream.readyState !== EventSource.OPEN)
      }
    })

    return () => {
      disposed = true
      source?.close()
    }
  }, [projectId])

  return { event, connectionLost }
}
