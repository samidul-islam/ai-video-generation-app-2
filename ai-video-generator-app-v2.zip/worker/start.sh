#!/usr/bin/env bash
set -euo pipefail

python /comfyui/main.py --listen 127.0.0.1 --port 8188 --disable-auto-launch &
exec python -u /worker/runpod_worker.py
