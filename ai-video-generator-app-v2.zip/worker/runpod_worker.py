"""RunPod Serverless handler: runs a ComfyUI (MiniMax H3) workflow, transcodes, uploads to S3/CDN."""

import copy
import json
import logging
import os
import random
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import boto3
import requests
import runpod

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("worker")

COMFY_URL = os.getenv("COMFY_URL", "http://127.0.0.1:8188")
COMFY_INPUT_DIR = Path(os.getenv("COMFY_INPUT_DIR", "/comfyui/input"))
COMFY_OUTPUT_DIR = Path(os.getenv("COMFY_OUTPUT_DIR", "/comfyui/output"))
WORKFLOW_PATH = Path(os.getenv("WORKFLOW_PATH", "/workflows/minimax_h3_workflow.json"))
COMFY_TIMEOUT_SECONDS = int(os.getenv("COMFY_TIMEOUT_SECONDS", "1500"))
EXPECTED_RENDER_SECONDS = int(os.getenv("EXPECTED_RENDER_SECONDS", "240"))
MUX_REFERENCE_AUDIO = os.getenv("MUX_REFERENCE_AUDIO", "true").lower() == "true"
NEGATIVE_PROMPT = os.getenv(
    "NEGATIVE_PROMPT", "blurry, distorted face, extra limbs, watermark, text, low quality, jitter"
)

S3_BUCKET = os.environ.get("S3_BUCKET", "")
S3_ENDPOINT_URL = os.getenv("S3_ENDPOINT_URL") or None
S3_REGION = os.getenv("S3_REGION", "auto")
CDN_BASE_URL = os.getenv("CDN_BASE_URL", "").rstrip("/")

# Only fetch media from our own storage to prevent SSRF from crafted job inputs.
ALLOWED_MEDIA_HOSTS = {h.strip() for h in os.getenv("ALLOWED_MEDIA_HOSTS", "").split(",") if h.strip()}
MAX_MEDIA_BYTES = int(os.getenv("MAX_MEDIA_MB", "25")) * 1024 * 1024

RESOLUTIONS = {"1080p": (1920, 1080), "720p": (1280, 720)}
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mov", ".mkv", ".gif"}

_s3 = boto3.client("s3", endpoint_url=S3_ENDPOINT_URL, region_name=S3_REGION)


class WorkerError(Exception):
    pass


def report(job: dict, percent: int, message: str) -> None:
    log.info("[%s] %s%% %s", job["id"], percent, message)
    runpod.serverless.progress_update(job, f"{percent}|{message}")


def validate_input(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise WorkerError("Job input must be an object.")
    prompt = (raw.get("prompt") or "").strip()
    if not prompt:
        raise WorkerError("'prompt' is required.")
    audio_mode = raw.get("audio_mode", "native")
    if audio_mode not in ("native", "hq_bengali"):
        raise WorkerError("Invalid audio_mode.")
    if audio_mode == "hq_bengali" and not raw.get("audio_url"):
        raise WorkerError("audio_url is required for hq_bengali mode.")
    images = raw.get("reference_image_urls") or []
    if not isinstance(images, list) or len(images) > 4:
        raise WorkerError("reference_image_urls must be a list of up to 4 URLs.")
    resolution = raw.get("resolution", "1080p")
    if resolution not in RESOLUTIONS:
        raise WorkerError("Invalid resolution.")
    duration = int(raw.get("duration_seconds", 6))
    output_prefix = (raw.get("output_prefix") or f"videos/{uuid.uuid4()}").strip("/")
    if ".." in output_prefix:
        raise WorkerError("Invalid output_prefix.")
    return {
        **raw,
        "prompt": prompt,
        "audio_mode": audio_mode,
        "reference_image_urls": images,
        "resolution": resolution,
        "duration_seconds": max(3, min(10, duration)),
        "output_prefix": output_prefix,
    }


def download(url: str, destination: Path) -> Path:
    parsed = urlparse(url)
    if parsed.scheme != "https" or (ALLOWED_MEDIA_HOSTS and parsed.hostname not in ALLOWED_MEDIA_HOSTS):
        raise WorkerError(f"Media host not allowed: {parsed.hostname}")
    with requests.get(url, stream=True, timeout=60) as response:
        response.raise_for_status()
        size = 0
        with open(destination, "wb") as handle:
            for chunk in response.iter_content(chunk_size=1 << 16):
                size += len(chunk)
                if size > MAX_MEDIA_BYTES:
                    raise WorkerError("Media file is too large.")
                handle.write(chunk)
    return destination


def _suffix(url: str, default: str) -> str:
    suffix = Path(urlparse(url).path).suffix.lower()
    return suffix if suffix and len(suffix) <= 5 else default


def wait_for_comfy(timeout: int = 180) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if requests.get(f"{COMFY_URL}/system_stats", timeout=5).ok:
                return
        except requests.RequestException:
            pass
        time.sleep(1)
    raise WorkerError("ComfyUI did not become ready in time.")


def _substitute(node: Any, values: dict[str, Any]) -> Any:
    """Replace {{PLACEHOLDER}} tokens. A string that is exactly one token keeps the value's native type."""
    if isinstance(node, dict):
        return {key: _substitute(value, values) for key, value in node.items()}
    if isinstance(node, list):
        return [_substitute(value, values) for value in node]
    if isinstance(node, str):
        for token, value in values.items():
            placeholder = "{{" + token + "}}"
            if node == placeholder:
                return value
            if placeholder in node:
                node = node.replace(placeholder, "" if value is None else str(value))
        return node
    return node


def build_workflow(inp: dict[str, Any], image_names: list[str], audio_name: str | None) -> dict[str, Any]:
    template = json.loads(WORKFLOW_PATH.read_text(encoding="utf-8"))
    template.pop("_meta", None)
    width, height = RESOLUTIONS["1080p"]
    fps = int(os.getenv("OUTPUT_FPS", "24"))
    values: dict[str, Any] = {
        "PROMPT": inp["prompt"],
        "NEGATIVE_PROMPT": NEGATIVE_PROMPT,
        "DIALOGUE": inp.get("dialogue") or "",
        "SOUND_EFFECTS": inp.get("sound_effects") or "",
        "AUDIO_MODE": inp["audio_mode"],
        "USE_NATIVE_AUDIO": inp["audio_mode"] == "native",
        "AUDIO": audio_name or "",
        "WIDTH": width,
        "HEIGHT": height,
        "FPS": fps,
        "DURATION": inp["duration_seconds"],
        "FRAMES": inp["duration_seconds"] * fps,
        "SEED": random.randint(0, 2**31 - 1),
        "IMAGE_COUNT": len(image_names),
    }
    for index in range(4):
        values[f"IMAGE_{index + 1}"] = image_names[index] if index < len(image_names) else (
            image_names[0] if image_names else ""
        )
    return _substitute(copy.deepcopy(template), values)


def queue_prompt(workflow: dict[str, Any], client_id: str) -> str:
    response = requests.post(
        f"{COMFY_URL}/prompt", json={"prompt": workflow, "client_id": client_id}, timeout=30
    )
    if not response.ok:
        raise WorkerError(f"ComfyUI rejected workflow: {response.text[:500]}")
    return response.json()["prompt_id"]


def _find_video(outputs: dict[str, Any]) -> Path | None:
    for node_output in outputs.values():
        for key in ("videos", "gifs", "images"):
            for item in node_output.get(key, []) or []:
                filename = item.get("filename", "")
                if Path(filename).suffix.lower() in VIDEO_EXTENSIONS:
                    base = COMFY_OUTPUT_DIR if item.get("type", "output") == "output" else COMFY_OUTPUT_DIR.parent / item["type"]
                    return base / item.get("subfolder", "") / filename
    return None


def wait_for_output(job: dict, prompt_id: str) -> Path:
    started = time.time()
    while time.time() - started < COMFY_TIMEOUT_SECONDS:
        response = requests.get(f"{COMFY_URL}/history/{prompt_id}", timeout=15)
        history = response.json().get(prompt_id) if response.ok else None
        if history:
            status = history.get("status", {})
            if status.get("status_str") == "error":
                messages = [m for m in status.get("messages", []) if m and m[0] == "execution_error"]
                detail = messages[0][1].get("exception_message") if messages else "unknown error"
                raise WorkerError(f"ComfyUI execution failed: {detail}")
            if status.get("completed", True):
                video = _find_video(history.get("outputs", {}))
                if not video or not video.exists():
                    raise WorkerError("Workflow finished but produced no video file.")
                return video

        elapsed = time.time() - started
        percent = 25 + int(min(elapsed / EXPECTED_RENDER_SECONDS, 0.97) * 60)
        report(job, percent, "Rendering frames on GPU")
        time.sleep(3)
    raise WorkerError("Rendering timed out.")


def ffmpeg(*args: str) -> None:
    result = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *args], capture_output=True, text=True)
    if result.returncode != 0:
        raise WorkerError(f"ffmpeg failed: {result.stderr[-500:]}")


def transcode(source: Path, destination: Path, height: int, audio: Path | None) -> None:
    inputs = ["-i", str(source)]
    maps = ["-map", "0:v:0", "-map", "0:a?"]
    if audio:
        inputs += ["-i", str(audio)]
        maps = ["-map", "0:v:0", "-map", "1:a:0", "-shortest"]
    ffmpeg(
        *inputs,
        *maps,
        "-vf", f"scale=-2:{height}:flags=lanczos,format=yuv420p",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18" if height >= 1080 else "21",
        "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart",
        str(destination),
    )


def upload(path: Path, key: str, content_type: str) -> str:
    _s3.upload_file(
        str(path),
        S3_BUCKET,
        key,
        ExtraArgs={"ContentType": content_type, "CacheControl": "public, max-age=31536000, immutable"},
    )
    return f"{CDN_BASE_URL}/{key}"


def handler(job: dict) -> dict[str, Any]:
    try:
        if not S3_BUCKET or not CDN_BASE_URL:
            raise WorkerError("S3_BUCKET and CDN_BASE_URL must be configured.")
        inp = validate_input(job.get("input") or {})
        job_tag = f"{job['id']}_{uuid.uuid4().hex[:6]}"

        report(job, 5, "Preparing assets")
        wait_for_comfy()
        COMFY_INPUT_DIR.mkdir(parents=True, exist_ok=True)

        image_names: list[str] = []
        for index, url in enumerate(inp["reference_image_urls"]):
            name = f"{job_tag}_ref{index + 1}{_suffix(url, '.png')}"
            download(url, COMFY_INPUT_DIR / name)
            image_names.append(name)

        audio_name = None
        audio_path = None
        if inp["audio_mode"] == "hq_bengali":
            audio_name = f"{job_tag}_voice{_suffix(inp['audio_url'], '.wav')}"
            audio_path = download(inp["audio_url"], COMFY_INPUT_DIR / audio_name)

        report(job, 15, "Queueing workflow")
        prompt_id = queue_prompt(build_workflow(inp, image_names, audio_name), client_id=job_tag)

        report(job, 25, "Rendering frames on GPU")
        raw_video = wait_for_output(job, prompt_id)

        report(job, 88, "Encoding 1080p and 720p")
        mux_audio = audio_path if (audio_path and MUX_REFERENCE_AUDIO) else None
        with tempfile.TemporaryDirectory() as work:
            work_dir = Path(work)
            master = work_dir / "video_1080p.mp4"
            preview = work_dir / "video_720p.mp4"
            thumbnail = work_dir / "thumbnail.jpg"
            transcode(raw_video, master, 1080, mux_audio)
            transcode(master, preview, 720, None)
            ffmpeg("-ss", "0.5", "-i", str(master), "-frames:v", "1", "-q:v", "3", str(thumbnail))

            report(job, 95, "Uploading to CDN")
            prefix = inp["output_prefix"]
            result = {
                "video_url_1080p": upload(master, f"{prefix}/video_1080p.mp4", "video/mp4"),
                "video_url_720p": upload(preview, f"{prefix}/video_720p.mp4", "video/mp4"),
                "thumbnail_url": upload(thumbnail, f"{prefix}/thumbnail.jpg", "image/jpeg"),
                "duration_seconds": inp["duration_seconds"],
            }

        for name in [*image_names, *([audio_name] if audio_name else [])]:
            (COMFY_INPUT_DIR / name).unlink(missing_ok=True)
        raw_video.unlink(missing_ok=True)
        return result
    except WorkerError as exc:
        log.error("Job %s failed: %s", job.get("id"), exc)
        return {"error": str(exc)}
    except Exception as exc:  # noqa: BLE001 - surface any crash to the API instead of hanging the job
        log.exception("Unexpected failure in job %s", job.get("id"))
        return {"error": f"Unexpected worker error: {exc}"}


if __name__ == "__main__":
    runpod.serverless.start({"handler": handler})
