import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.errors import RepositoryError
from app.core.http import close_http_client
from app.routers import admin, app_config, audio, projects, prompt, uploads, video

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    await close_http_client()


settings = get_settings()

app = FastAPI(
    title="ChobiAI — Video & Talking Avatar API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.exception_handler(RepositoryError)
async def repository_error_handler(_request: Request, exc: RepositoryError):
    status_code = exc.status_code if 400 <= exc.status_code < 600 else 500
    logging.getLogger("repository").error("Repository error: %s", exc)
    message = "Not found." if status_code == 404 else "Database error."
    return JSONResponse(status_code=status_code, content={"detail": message})


@app.get("/health", tags=["meta"])
async def health():
    return {"status": "ok", "env": settings.app_env, "db_provider": settings.db_provider}


for router in (
    prompt.router,
    audio.router,
    uploads.router,
    video.router,
    projects.router,
    app_config.router,
    admin.router,
):
    app.include_router(router, prefix="/api/v1")
