"""Firestore implementation of ProjectRepository. Enable with DB_PROVIDER=firebase."""

import uuid
from datetime import datetime, timezone
from typing import Any

from starlette.concurrency import run_in_threadpool

from app.core.config import get_settings
from app.core.errors import InsufficientCreditsError, NotConfiguredError, RepositoryError
from app.schemas import Project

_app = None


def get_firebase_app():
    global _app
    if _app is None:
        import firebase_admin
        from firebase_admin import credentials

        import json

        settings = get_settings()
        if settings.firebase_credentials_json:
            cert = credentials.Certificate(json.loads(settings.firebase_credentials_json))
        elif settings.firebase_credentials_path:
            cert = credentials.Certificate(settings.firebase_credentials_path)
        else:
            raise NotConfiguredError("Firebase")
        options = {"storageBucket": settings.firebase_storage_bucket} if settings.firebase_storage_bucket else None
        _app = firebase_admin.initialize_app(cert, options)
    return _app


class FirebaseRepository:
    def __init__(self) -> None:
        from firebase_admin import firestore

        self._firestore = firestore
        self._db = firestore.client(app=get_firebase_app())
        self._projects = self._db.collection("projects")
        self._credits = self._db.collection("user_credits")

    @staticmethod
    def _to_project(doc) -> Project:
        return Project.model_validate({**doc.to_dict(), "id": doc.id})

    async def create_project(self, user_id: str, data: dict[str, Any]) -> Project:
        def _create() -> Project:
            now = datetime.now(timezone.utc)
            project_id = str(uuid.uuid4())
            record = {
                "status": "draft",
                "progress": 0,
                "credits_charged": 0,
                "credits_refunded": False,
                **data,
                "user_id": user_id,
                "created_at": now,
                "updated_at": now,
            }
            self._projects.document(project_id).set(record)
            return Project.model_validate({**record, "id": project_id})

        return await run_in_threadpool(_create)

    async def get_project(self, user_id: str, project_id: str) -> Project | None:
        project = await self.get_project_internal(project_id)
        return project if project and project.user_id == user_id else None

    async def get_project_internal(self, project_id: str) -> Project | None:
        doc = await run_in_threadpool(self._projects.document(project_id).get)
        return self._to_project(doc) if doc.exists else None

    async def list_projects(self, user_id: str, limit: int, offset: int) -> list[Project]:
        def _list() -> list[Project]:
            query = (
                self._projects.where("user_id", "==", user_id)
                .order_by("created_at", direction=self._firestore.Query.DESCENDING)
                .offset(offset)
                .limit(limit)
            )
            return [self._to_project(doc) for doc in query.stream()]

        return await run_in_threadpool(_list)

    async def update_project(self, project_id: str, data: dict[str, Any]) -> Project:
        def _update() -> Project:
            ref = self._projects.document(project_id)
            if not ref.get().exists:
                raise RepositoryError("Project not found", 404)
            ref.update({**data, "updated_at": datetime.now(timezone.utc)})
            return self._to_project(ref.get())

        return await run_in_threadpool(_update)

    async def delete_project(self, user_id: str, project_id: str) -> bool:
        project = await self.get_project(user_id, project_id)
        if not project:
            return False
        await run_in_threadpool(self._projects.document(project_id).delete)
        return True

    async def mark_refunded(self, project_id: str) -> bool:
        ref = self._projects.document(project_id)

        @self._firestore.transactional
        def _mark(transaction) -> bool:
            snapshot = ref.get(transaction=transaction)
            if not snapshot.exists or snapshot.get("credits_refunded"):
                return False
            transaction.update(ref, {"credits_refunded": True})
            return True

        return await run_in_threadpool(_mark, self._db.transaction())

    async def _adjust_credits(self, user_id: str, delta: int) -> int:
        ref = self._credits.document(user_id)
        starting = get_settings().starting_credits

        @self._firestore.transactional
        def _adjust(transaction) -> int:
            snapshot = ref.get(transaction=transaction)
            balance = snapshot.get("balance") if snapshot.exists else starting
            new_balance = balance + delta
            if new_balance < 0:
                raise InsufficientCreditsError()
            transaction.set(ref, {"balance": new_balance, "updated_at": datetime.now(timezone.utc)})
            return new_balance

        return await run_in_threadpool(_adjust, self._db.transaction())

    async def get_credits(self, user_id: str) -> int:
        return await self._adjust_credits(user_id, 0)

    async def consume_credits(self, user_id: str, amount: int) -> int:
        return await self._adjust_credits(user_id, -amount)

    async def refund_credits(self, user_id: str, amount: int) -> int:
        return await self._adjust_credits(user_id, amount)
