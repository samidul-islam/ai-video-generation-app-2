"""Firestore-backed storage for app configuration, user profiles and admin analytics.

Collections:
  app_config/{credits|settings|theme}   singleton config documents
  users/{uid}                            profile (name, username, phone, country, photo_url, role)
  user_credits/{uid}                     balance (shared with FirebaseRepository's credit engine)
  projects/{id}                          generation history
"""

from collections import Counter
from datetime import datetime, timedelta, timezone
from typing import Any, TypeVar

from fastapi import HTTPException, status
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

from app.core.config import get_settings
from app.db.firebase_repository import get_firebase_app
from app.schemas import (
    AdminStats,
    AppSettings,
    CreditConfig,
    DailyPoint,
    HistoryItem,
    Project,
    ThemeConfig,
    UserCreate,
    UserProfile,
    UserUpdate,
)

M = TypeVar("M", bound=BaseModel)

SECRET_FIELDS = {"api_key", "webhook_secret"}
MASK = "••••••••"


def mask_secrets(settings: AppSettings) -> AppSettings:
    data = settings.model_dump()
    for section in data.values():
        for key in SECRET_FIELDS & section.keys():
            if section[key]:
                section[key] = MASK
    return AppSettings.model_validate(data)


class AdminStore:
    def __init__(self) -> None:
        from firebase_admin import auth, firestore

        app = get_firebase_app()
        self._auth = auth
        self._app = app
        self._firestore = firestore
        self._db = firestore.client(app=app)
        self._config = self._db.collection("app_config")
        self._users = self._db.collection("users")
        self._credits = self._db.collection("user_credits")
        self._projects = self._db.collection("projects")

    # ---------- config ----------

    async def _get_config(self, name: str, model: type[M]) -> M:
        doc = await run_in_threadpool(self._config.document(name).get)
        return model.model_validate(doc.to_dict() or {}) if doc.exists else model()

    async def _set_config(self, name: str, value: BaseModel) -> None:
        await run_in_threadpool(self._config.document(name).set, value.model_dump())

    async def get_credit_config(self) -> CreditConfig:
        return await self._get_config("credits", CreditConfig)

    async def set_credit_config(self, value: CreditConfig) -> CreditConfig:
        await self._set_config("credits", value)
        return value

    async def get_settings(self) -> AppSettings:
        return await self._get_config("settings", AppSettings)

    async def set_settings(self, incoming: AppSettings) -> AppSettings:
        """Masked secrets coming back from the UI keep their stored value."""
        current = (await self.get_settings()).model_dump()
        merged = incoming.model_dump()
        for section_name, section in merged.items():
            for key in SECRET_FIELDS & section.keys():
                if section[key] == MASK:
                    section[key] = current.get(section_name, {}).get(key, "")
        value = AppSettings.model_validate(merged)
        await self._set_config("settings", value)
        return value

    async def get_theme(self) -> ThemeConfig:
        return await self._get_config("theme", ThemeConfig)

    async def set_theme(self, value: ThemeConfig) -> ThemeConfig:
        await self._set_config("theme", value)
        return value

    # ---------- users ----------

    def _profile(self, uid: str, profile: dict[str, Any], balance: int | None, record=None) -> UserProfile:
        return UserProfile(
            id=uid,
            name=profile.get("name") or (record.display_name if record else "") or "",
            username=profile.get("username", ""),
            email=profile.get("email") or (record.email if record else "") or "",
            phone=profile.get("phone", ""),
            country=profile.get("country", ""),
            photo_url=profile.get("photo_url") or (record.photo_url if record else "") or "",
            credits=balance if balance is not None else get_settings().starting_credits,
            role=profile.get("role", "user"),
            disabled=bool(record.disabled) if record else bool(profile.get("disabled", False)),
            created_at=profile.get("created_at"),
        )

    async def ensure_profile(self, uid: str, email: str = "", name: str = "") -> UserProfile:
        def _ensure() -> UserProfile:
            ref = self._users.document(uid)
            snap = ref.get()
            if not snap.exists:
                admin_emails = {e.lower() for e in get_settings().admin_emails}
                data = {
                    "email": email,
                    "name": name,
                    "username": (email.split("@")[0] if email else uid[:8]),
                    "role": "admin" if email and email.lower() in admin_emails else "user",
                    "created_at": datetime.now(timezone.utc),
                }
                ref.set(data)
            else:
                data = snap.to_dict() or {}
            credits = self._credits.document(uid).get()
            return self._profile(uid, data, credits.get("balance") if credits.exists else None)

        return await run_in_threadpool(_ensure)

    async def list_users(self, search: str = "") -> list[UserProfile]:
        def _list() -> list[UserProfile]:
            balances = {doc.id: (doc.to_dict() or {}).get("balance") for doc in self._credits.stream()}
            users = [
                self._profile(doc.id, doc.to_dict() or {}, balances.get(doc.id))
                for doc in self._users.order_by("created_at", direction=self._firestore.Query.DESCENDING).stream()
            ]
            if search:
                needle = search.lower()
                users = [
                    u for u in users
                    if needle in f"{u.name} {u.username} {u.email} {u.phone} {u.country}".lower()
                ]
            return users

        return await run_in_threadpool(_list)

    async def create_user(self, body: UserCreate) -> UserProfile:
        def _create() -> UserProfile:
            try:
                record = self._auth.create_user(
                    email=body.email,
                    password=body.password,
                    display_name=body.name,
                    photo_url=body.photo_url or None,
                    app=self._app,
                )
            except self._auth.EmailAlreadyExistsError as exc:
                raise HTTPException(status.HTTP_409_CONFLICT, "Email already in use.") from exc
            profile = {
                "name": body.name,
                "username": body.username,
                "email": body.email,
                "phone": body.phone,
                "country": body.country,
                "photo_url": body.photo_url,
                "role": body.role,
                "created_at": datetime.now(timezone.utc),
            }
            self._users.document(record.uid).set(profile)
            self._credits.document(record.uid).set(
                {"balance": body.credits, "updated_at": datetime.now(timezone.utc)}
            )
            return self._profile(record.uid, profile, body.credits, record)

        return await run_in_threadpool(_create)

    async def update_user(self, uid: str, body: UserUpdate) -> UserProfile:
        def _update() -> UserProfile:
            updates = body.model_dump(exclude_unset=True)
            auth_updates: dict[str, Any] = {}
            for src, dst in (("email", "email"), ("password", "password"), ("name", "display_name"),
                             ("photo_url", "photo_url"), ("disabled", "disabled")):
                if src in updates:
                    auth_updates[dst] = updates[src] or None if src == "photo_url" else updates[src]
            try:
                if auth_updates:
                    self._auth.update_user(uid, app=self._app, **auth_updates)
            except self._auth.UserNotFoundError:
                pass  # profile-only users (e.g. the dev user) have no Auth record
            if "credits" in updates:
                self._credits.document(uid).set(
                    {"balance": updates.pop("credits"), "updated_at": datetime.now(timezone.utc)}
                )
            updates.pop("password", None)
            if updates:
                self._users.document(uid).set(updates, merge=True)
            profile = self._users.document(uid).get().to_dict() or {}
            credits = self._credits.document(uid).get()
            return self._profile(uid, profile, credits.get("balance") if credits.exists else None)

        return await run_in_threadpool(_update)

    async def delete_user(self, uid: str) -> None:
        def _delete() -> None:
            try:
                self._auth.delete_user(uid, app=self._app)
            except self._auth.UserNotFoundError:
                pass
            self._users.document(uid).delete()
            self._credits.document(uid).delete()

        await run_in_threadpool(_delete)

    # ---------- history & analytics ----------

    async def list_history(
        self,
        user_id: str | None,
        status_filter: str | None,
        resolution: str | None,
        date_from: datetime | None,
        date_to: datetime | None,
        search: str,
        limit: int,
    ) -> list[HistoryItem]:
        def _list() -> list[HistoryItem]:
            query = self._projects
            if user_id:
                query = query.where("user_id", "==", user_id)
            if status_filter:
                query = query.where("status", "==", status_filter)
            if resolution:
                query = query.where("resolution", "==", resolution)
            if date_from:
                query = query.where("created_at", ">=", date_from)
            if date_to:
                query = query.where("created_at", "<=", date_to)
            query = query.order_by("created_at", direction=self._firestore.Query.DESCENDING).limit(limit)
            projects = [Project.model_validate({**doc.to_dict(), "id": doc.id}) for doc in query.stream()]

            ids = {p.user_id for p in projects}
            profiles = {
                doc.id: doc.to_dict() or {}
                for doc in self._db.get_all([self._users.document(i) for i in ids])
                if doc.exists
            } if ids else {}
            items = [
                HistoryItem(
                    **p.model_dump(),
                    user_email=profiles.get(p.user_id, {}).get("email", ""),
                    user_name=profiles.get(p.user_id, {}).get("name", ""),
                )
                for p in projects
            ]
            if search:
                needle = search.lower()
                items = [i for i in items if needle in f"{i.title} {i.raw_prompt} {i.user_email}".lower()]
            return items

        return await run_in_threadpool(_list)

    async def stats(self, days: int = 14) -> AdminStats:
        def _stats() -> AdminStats:
            since = datetime.now(timezone.utc) - timedelta(days=days - 1)
            total_users = self._users.count().get()[0][0].value
            total_videos = self._projects.count().get()[0][0].value
            recent = [doc.to_dict() or {} for doc in self._projects.where("created_at", ">=", since).stream()]

            statuses = Counter(p.get("status") for p in recent)
            daily: dict[str, DailyPoint] = {}
            for offset in range(days):
                key = (since + timedelta(days=offset)).strftime("%Y-%m-%d")
                daily[key] = DailyPoint(date=key, videos=0, credits=0)
            consumed = 0
            for p in recent:
                key = p["created_at"].strftime("%Y-%m-%d")
                charged = 0 if p.get("credits_refunded") else int(p.get("credits_charged", 0))
                consumed += charged
                if key in daily:
                    daily[key].videos += 1
                    daily[key].credits += charged
            return AdminStats(
                total_users=total_users,
                total_videos=total_videos,
                completed_videos=statuses.get("completed", 0),
                failed_videos=statuses.get("failed", 0) + statuses.get("cancelled", 0),
                active_jobs=statuses.get("queued", 0) + statuses.get("rendering", 0),
                credits_consumed=consumed,
                daily=list(daily.values()),
                resolution_split=dict(Counter(p.get("resolution", "540p") for p in recent)),
                audio_split=dict(Counter(p.get("audio_mode", "native") for p in recent)),
            )

        return await run_in_threadpool(_stats)


_store: AdminStore | None = None


def get_admin_store() -> AdminStore:
    global _store
    if _store is None:
        _store = AdminStore()
    return _store
