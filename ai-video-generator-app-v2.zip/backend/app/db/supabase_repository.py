from typing import Any

import httpx

from app.core.config import get_settings
from app.core.errors import InsufficientCreditsError, NotConfiguredError, RepositoryError
from app.core.http import get_http_client
from app.schemas import Project


class SupabaseRepository:
    """Talks to Supabase PostgREST with the service-role key. Every user-facing query is scoped by user_id."""

    def __init__(self) -> None:
        settings = get_settings()
        if not settings.supabase_url or not settings.supabase_service_role_key:
            raise NotConfiguredError("Supabase")
        key = settings.supabase_service_role_key
        self._rest = f"{settings.supabase_url.rstrip('/')}/rest/v1"
        self._headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json: Any = None,
        prefer: str | None = None,
    ) -> Any:
        headers = dict(self._headers)
        if prefer:
            headers["Prefer"] = prefer
        try:
            response = await get_http_client().request(
                method, f"{self._rest}/{path}", params=params, json=json, headers=headers
            )
        except httpx.HTTPError as exc:
            raise RepositoryError(f"Supabase request failed: {exc}", 502) from exc
        if response.status_code >= 400:
            raise RepositoryError(response.text[:500], response.status_code)
        return response.json() if response.content else None

    async def create_project(self, user_id: str, data: dict[str, Any]) -> Project:
        rows = await self._request(
            "POST", "projects", json={**data, "user_id": user_id}, prefer="return=representation"
        )
        return Project.model_validate(rows[0])

    async def get_project(self, user_id: str, project_id: str) -> Project | None:
        rows = await self._request(
            "GET",
            "projects",
            params={"id": f"eq.{project_id}", "user_id": f"eq.{user_id}", "limit": "1"},
        )
        return Project.model_validate(rows[0]) if rows else None

    async def get_project_internal(self, project_id: str) -> Project | None:
        rows = await self._request("GET", "projects", params={"id": f"eq.{project_id}", "limit": "1"})
        return Project.model_validate(rows[0]) if rows else None

    async def list_projects(self, user_id: str, limit: int, offset: int) -> list[Project]:
        rows = await self._request(
            "GET",
            "projects",
            params={
                "user_id": f"eq.{user_id}",
                "order": "created_at.desc",
                "limit": str(limit),
                "offset": str(offset),
            },
        )
        return [Project.model_validate(row) for row in rows]

    async def update_project(self, project_id: str, data: dict[str, Any]) -> Project:
        rows = await self._request(
            "PATCH",
            "projects",
            params={"id": f"eq.{project_id}"},
            json=data,
            prefer="return=representation",
        )
        if not rows:
            raise RepositoryError("Project not found", 404)
        return Project.model_validate(rows[0])

    async def delete_project(self, user_id: str, project_id: str) -> bool:
        rows = await self._request(
            "DELETE",
            "projects",
            params={"id": f"eq.{project_id}", "user_id": f"eq.{user_id}"},
            prefer="return=representation",
        )
        return bool(rows)

    async def mark_refunded(self, project_id: str) -> bool:
        rows = await self._request(
            "PATCH",
            "projects",
            params={"id": f"eq.{project_id}", "credits_refunded": "eq.false"},
            json={"credits_refunded": True},
            prefer="return=representation",
        )
        return bool(rows)

    async def _rpc(self, fn: str, payload: dict[str, Any]) -> int:
        try:
            result = await self._request("POST", f"rpc/{fn}", json=payload)
        except RepositoryError as exc:
            if "insufficient_credits" in str(exc):
                raise InsufficientCreditsError() from exc
            raise
        return int(result)

    async def get_credits(self, user_id: str) -> int:
        return await self._rpc(
            "get_credits", {"p_user_id": user_id, "p_starting": get_settings().starting_credits}
        )

    async def consume_credits(self, user_id: str, amount: int) -> int:
        return await self._rpc(
            "consume_credits",
            {"p_user_id": user_id, "p_amount": amount, "p_starting": get_settings().starting_credits},
        )

    async def refund_credits(self, user_id: str, amount: int) -> int:
        return await self._rpc("refund_credits", {"p_user_id": user_id, "p_amount": amount})
