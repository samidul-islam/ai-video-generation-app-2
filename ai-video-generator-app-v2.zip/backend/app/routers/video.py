import asyncio
import hmac
import logging
from collections.abc import AsyncIterator
from urllib.parse import urlencode
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import StreamingResponse

from app.core.config import get_settings
from app.db.base import ProjectRepository
from app.deps import get_current_user, get_repository
from app.core.errors import NotConfiguredError
from app.db.admin_store import get_admin_store
from app.schemas import (
    TERMINAL_STATUSES,
    CreditConfig,
    GenerateVideoRequest,
    GenerateVideoResponse,
    JobEvent,
    ParsedPrompt,
    Project,
)
from app.services import runpod
from app.services.pricing import video_cost
from app.services.jobs import _fail, apply_runpod_payload, sync_project_with_runpod
from app.services.storage import get_storage

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/generate-video", tags=["video"])


def _to_event(project: Project) -> JobEvent:
    return JobEvent(
        project_id=project.id,
        status=project.status,
        progress=project.progress,
        message=project.status_message or project.error,
        project=project,
    )


def _webhook_url(project_id: str) -> str | None:
    settings = get_settings()
    if not settings.runpod_webhook_secret:
        return None
    query = urlencode({"project_id": project_id, "token": settings.runpod_webhook_secret})
    return f"{settings.public_base_url.rstrip('/')}/api/v1/generate-video/webhook?{query}"


@router.post("", response_model=GenerateVideoResponse, status_code=status.HTTP_202_ACCEPTED)
async def generate_video(
    body: GenerateVideoRequest,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    storage = get_storage()
    media_urls = [*body.reference_image_urls, *([body.audio_url] if body.audio_url else [])]
    if any(not storage.is_owned_url(url) for url in media_urls):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Media must be uploaded through this API.")

    try:
        credit_config = await get_admin_store().get_credit_config()
    except NotConfiguredError:
        credit_config = CreditConfig()
    cost = video_cost(credit_config, body.resolution, body.duration_seconds, body.audio_mode == "native")
    balance = await repo.consume_credits(user_id, cost)

    parsed = body.parsed_prompt or ParsedPrompt(
        visual_prompt=body.raw_prompt,
        character_mapping="",
        dialogue="",
        sound_effects="",
        full_minimax_prompt=body.raw_prompt,
    )

    project = await repo.create_project(
        user_id,
        {
            "title": body.title or body.raw_prompt[:60],
            "mode": body.mode,
            "raw_prompt": body.raw_prompt,
            "parsed_prompt": parsed.model_dump(),
            "audio_mode": body.audio_mode,
            "tts_provider": body.tts_provider if body.audio_mode == "hq_bengali" else None,
            "audio_url": body.audio_url,
            "reference_image_urls": body.reference_image_urls,
            "resolution": body.resolution,
            "aspect_ratio": body.aspect_ratio,
            "duration_seconds": body.duration_seconds,
            "status": "queued",
            "progress": 5,
            "status_message": "Submitting job",
            "credits_charged": cost,
        },
    )

    job_input = {
        "project_id": project.id,
        "output_prefix": f"{user_id}/videos/{project.id}",
        "mode": body.mode,
        "prompt": parsed.full_minimax_prompt,
        "visual_prompt": parsed.visual_prompt,
        "character_mapping": parsed.character_mapping,
        "dialogue": parsed.dialogue,
        "sound_effects": parsed.sound_effects,
        "audio_mode": body.audio_mode,
        "audio_url": body.audio_url,
        "reference_image_urls": body.reference_image_urls,
        "resolution": body.resolution,
        "aspect_ratio": body.aspect_ratio,
        "duration_seconds": body.duration_seconds,
    }

    try:
        job_id = await runpod.submit_job(job_input, _webhook_url(project.id))
    except HTTPException as exc:
        await _fail(repo, project, str(exc.detail))
        raise

    project = await repo.update_project(
        project.id, {"runpod_job_id": job_id, "progress": 8, "status_message": "Queued on RunPod"}
    )
    return GenerateVideoResponse(
        project_id=project.id, job_id=job_id, status=project.status, credits_charged=cost, balance=balance
    )


@router.get("/{project_id}/status", response_model=JobEvent)
async def job_status(
    project_id: UUID,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    project = await repo.get_project(user_id, str(project_id))
    if not project:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")
    return _to_event(await sync_project_with_runpod(repo, project))


@router.get("/{project_id}/events")
async def job_events(
    project_id: UUID,
    request: Request,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    project = await repo.get_project(user_id, str(project_id))
    if not project:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")

    poll_seconds = get_settings().sse_poll_seconds

    async def stream() -> AsyncIterator[str]:
        current = project
        while True:
            if await request.is_disconnected():
                break
            try:
                current = await repo.get_project_internal(current.id) or current
                current = await sync_project_with_runpod(repo, current)
            except HTTPException as exc:
                logger.warning("Status sync failed for %s: %s", current.id, exc.detail)

            yield f"event: progress\ndata: {_to_event(current).model_dump_json()}\n\n"
            if current.status in TERMINAL_STATUSES:
                yield "event: done\ndata: {}\n\n"
                break
            await asyncio.sleep(poll_seconds)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


@router.post("/{project_id}/cancel", response_model=JobEvent)
async def cancel_job(
    project_id: UUID,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    project = await repo.get_project(user_id, str(project_id))
    if not project:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")
    if project.status in TERMINAL_STATUSES:
        return _to_event(project)
    if project.runpod_job_id:
        await runpod.cancel_job(project.runpod_job_id)
    return _to_event(await _fail(repo, project, "Cancelled by user"))


@router.post("/webhook", include_in_schema=False)
async def runpod_webhook(
    request: Request,
    project_id: UUID = Query(...),
    token: str = Query(...),
    repo: ProjectRepository = Depends(get_repository),
):
    secret = get_settings().runpod_webhook_secret
    if not secret or not hmac.compare_digest(token, secret):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid webhook token.")

    payload = await request.json()
    project = await repo.get_project_internal(str(project_id))
    if not project or project.runpod_job_id != payload.get("id"):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown job.")

    await apply_runpod_payload(repo, project, payload)
    return {"ok": True}
