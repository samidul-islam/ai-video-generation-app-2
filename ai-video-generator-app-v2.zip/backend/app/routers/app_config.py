from fastapi import APIRouter, Depends

from app.db.admin_store import AdminStore, get_admin_store
from app.deps import AuthUser, get_auth_user
from app.schemas import MeResponse, PublicConfig

router = APIRouter(tags=["config"])


@router.get("/app-config", response_model=PublicConfig)
async def public_config(store: AdminStore = Depends(get_admin_store)):
    settings = await store.get_settings()
    return PublicConfig(meta=settings.meta, credits=await store.get_credit_config(), theme=await store.get_theme())


@router.get("/me", response_model=MeResponse)
async def me(user: AuthUser = Depends(get_auth_user), store: AdminStore = Depends(get_admin_store)):
    profile = await store.ensure_profile(user.uid, user.email, user.name)
    return MeResponse(profile=profile, is_admin=user.is_admin_claim or profile.role == "admin")
