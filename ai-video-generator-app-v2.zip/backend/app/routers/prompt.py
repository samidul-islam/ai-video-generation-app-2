from fastapi import APIRouter, Depends

from app.deps import get_current_user
from app.schemas import ParsedPrompt, ParsePromptRequest
from app.services import gemini

router = APIRouter(tags=["prompt"])


@router.post("/parse-prompt", response_model=ParsedPrompt)
async def parse_prompt(body: ParsePromptRequest, _user_id: str = Depends(get_current_user)):
    return await gemini.parse_prompt(body.text, body.character_count)
