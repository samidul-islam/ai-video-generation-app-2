import uuid

from fastapi import APIRouter, Depends

from app.core.config import get_settings
from app.db.base import ProjectRepository
from app.deps import get_current_user, get_repository
from app.schemas import GenerateAudioRequest, GenerateAudioResponse
from app.services import tts
from app.services.storage import get_storage

router = APIRouter(tags=["audio"])


@router.post("/generate-audio", response_model=GenerateAudioResponse)
async def generate_audio(
    body: GenerateAudioRequest,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    cost = get_settings().audio_credit_cost
    if cost:
        await repo.consume_credits(user_id, cost)

    try:
        audio = await tts.synthesize(body.provider, body.text, body.voice)
        url = await get_storage().upload(
            f"{user_id}/audio/{uuid.uuid4()}.{audio.extension}", audio.data, audio.content_type
        )
    except Exception:
        if cost:
            await repo.refund_credits(user_id, cost)
        raise

    return GenerateAudioResponse(audio_url=url, provider=body.provider, content_type=audio.content_type)
