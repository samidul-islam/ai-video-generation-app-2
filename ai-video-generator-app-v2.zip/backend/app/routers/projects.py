from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from app.core.config import get_settings
from app.db.base import ProjectRepository
from app.deps import get_current_user, get_repository
from app.schemas import CreditsResponse, Project, ProjectCreate, ProjectList, ProjectUpdate
from app.services.storage import get_storage

router = APIRouter(tags=["projects"])


def _assert_owned_media(urls: list[str]) -> None:
    storage = get_storage()
    if any(not storage.is_owned_url(url) for url in urls):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Media must be uploaded through this API.")


@router.get("/projects", response_model=ProjectList)
async def list_projects(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    return ProjectList(items=await repo.list_projects(user_id, limit, offset))


@router.post("/projects", response_model=Project, status_code=status.HTTP_201_CREATED)
async def create_project(
    body: ProjectCreate,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    _assert_owned_media([*body.reference_image_urls, *([body.audio_url] if body.audio_url else [])])
    return await repo.create_project(user_id, {**body.model_dump(mode="json"), "status": "draft"})


@router.get("/projects/{project_id}", response_model=Project)
async def get_project(
    project_id: UUID,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    project = await repo.get_project(user_id, str(project_id))
    if not project:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")
    return project


@router.patch("/projects/{project_id}", response_model=Project)
async def update_project(
    project_id: UUID,
    body: ProjectUpdate,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    project = await repo.get_project(user_id, str(project_id))
    if not project:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")
    updates = body.model_dump(mode="json", exclude_unset=True)
    _assert_owned_media([*(updates.get("reference_image_urls") or []), *([updates["audio_url"]] if updates.get("audio_url") else [])])
    if not updates:
        return project
    return await repo.update_project(project.id, updates)


@router.delete("/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_project(
    project_id: UUID,
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    if not await repo.delete_project(user_id, str(project_id)):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/me/credits", response_model=CreditsResponse)
async def get_credits(
    user_id: str = Depends(get_current_user),
    repo: ProjectRepository = Depends(get_repository),
):
    settings = get_settings()
    return CreditsResponse(
        balance=await repo.get_credits(user_id),
        video_cost=settings.video_credit_cost,
        audio_cost=settings.audio_credit_cost,
    )
