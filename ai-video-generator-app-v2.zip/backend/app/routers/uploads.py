import uuid

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status

from app.core.config import get_settings
from app.deps import get_current_user
from app.schemas import UploadResponse
from app.services.storage import get_storage

router = APIRouter(tags=["uploads"])

ALLOWED_IMAGE_TYPES = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}
MAX_FILES = 4


@router.post("/uploads", response_model=UploadResponse)
async def upload_references(
    files: list[UploadFile] = File(...),
    user_id: str = Depends(get_current_user),
):
    if not files or len(files) > MAX_FILES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Upload between 1 and {MAX_FILES} images.")

    max_bytes = get_settings().max_upload_mb * 1024 * 1024
    storage = get_storage()
    urls: list[str] = []

    for upload in files:
        extension = ALLOWED_IMAGE_TYPES.get(upload.content_type or "")
        if not extension:
            raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Only PNG, JPEG and WebP are allowed.")
        data = await upload.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Image is too large.")
        urls.append(
            await storage.upload(f"{user_id}/references/{uuid.uuid4()}.{extension}", data, upload.content_type)
        )

    return UploadResponse(urls=urls)
