from datetime import datetime

from fastapi import APIRouter, Depends, Query, Response, status

from app.db.admin_store import AdminStore, get_admin_store, mask_secrets
from app.deps import require_admin
from app.schemas import (
    AdminStats,
    AppSettings,
    CreditConfig,
    HistoryList,
    ProjectStatus,
    Resolution,
    ThemeConfig,
    UserCreate,
    UserList,
    UserProfile,
    UserUpdate,
)

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin)])


@router.get("/stats", response_model=AdminStats)
async def stats(days: int = Query(default=14, ge=1, le=90), store: AdminStore = Depends(get_admin_store)):
    return await store.stats(days)


@router.get("/history", response_model=HistoryList)
async def history(
    user_id: str | None = None,
    status_filter: ProjectStatus | None = Query(default=None, alias="status"),
    resolution: Resolution | None = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    search: str = Query(default="", max_length=120),
    limit: int = Query(default=100, ge=1, le=500),
    store: AdminStore = Depends(get_admin_store),
):
    items = await store.list_history(user_id, status_filter, resolution, date_from, date_to, search, limit)
    return HistoryList(items=items)


@router.get("/users", response_model=UserList)
async def list_users(search: str = Query(default="", max_length=120), store: AdminStore = Depends(get_admin_store)):
    return UserList(items=await store.list_users(search))


@router.post("/users", response_model=UserProfile, status_code=status.HTTP_201_CREATED)
async def create_user(body: UserCreate, store: AdminStore = Depends(get_admin_store)):
    return await store.create_user(body)


@router.patch("/users/{uid}", response_model=UserProfile)
async def update_user(uid: str, body: UserUpdate, store: AdminStore = Depends(get_admin_store)):
    return await store.update_user(uid, body)


@router.delete("/users/{uid}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(uid: str, store: AdminStore = Depends(get_admin_store)):
    await store.delete_user(uid)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/credits", response_model=CreditConfig)
async def get_credit_config(store: AdminStore = Depends(get_admin_store)):
    return await store.get_credit_config()


@router.put("/credits", response_model=CreditConfig)
async def set_credit_config(body: CreditConfig, store: AdminStore = Depends(get_admin_store)):
    return await store.set_credit_config(body)


@router.get("/settings", response_model=AppSettings)
async def get_settings(store: AdminStore = Depends(get_admin_store)):
    return mask_secrets(await store.get_settings())


@router.put("/settings", response_model=AppSettings)
async def set_settings(body: AppSettings, store: AdminStore = Depends(get_admin_store)):
    return mask_secrets(await store.set_settings(body))


@router.get("/theme", response_model=ThemeConfig)
async def get_theme(store: AdminStore = Depends(get_admin_store)):
    return await store.get_theme()


@router.put("/theme", response_model=ThemeConfig)
async def set_theme(body: ThemeConfig, store: AdminStore = Depends(get_admin_store)):
    return await store.set_theme(body)
