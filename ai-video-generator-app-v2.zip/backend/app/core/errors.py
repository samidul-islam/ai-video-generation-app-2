from fastapi import HTTPException, status


class UpstreamError(HTTPException):
    def __init__(self, service: str, detail: str):
        super().__init__(status_code=status.HTTP_502_BAD_GATEWAY, detail=f"{service}: {detail}")


class NotConfiguredError(HTTPException):
    def __init__(self, service: str):
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"{service} is not configured on the server.",
        )


class InsufficientCreditsError(HTTPException):
    def __init__(self):
        super().__init__(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail="Not enough credits.")


class RepositoryError(Exception):
    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message)
        self.status_code = status_code
