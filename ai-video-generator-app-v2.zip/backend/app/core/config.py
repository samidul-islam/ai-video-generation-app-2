from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "development"
    cors_origins: list[str] = ["http://localhost:3000"]
    public_base_url: str = "http://localhost:8000"

    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"

    google_tts_api_key: str = ""
    google_tts_language: str = "bn-IN"
    google_tts_voice: str = "bn-IN-Chirp3-HD-Achernar"

    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = ""
    elevenlabs_model_id: str = "eleven_v3"

    runpod_api_key: str = ""
    runpod_endpoint_id: str = ""
    runpod_webhook_secret: str = ""

    db_provider: Literal["supabase", "firebase"] = "firebase"
    supabase_url: str = ""
    supabase_service_role_key: str = ""
    supabase_storage_bucket: str = "media"
    firebase_credentials_path: str = ""
    firebase_credentials_json: str = ""
    firebase_storage_bucket: str = ""

    auth_required: bool = False
    dev_user_id: str = "00000000-0000-0000-0000-000000000000"
    admin_emails: list[str] = []

    video_credit_cost: int = 10
    audio_credit_cost: int = 1
    starting_credits: int = 100
    max_upload_mb: int = 10
    sse_poll_seconds: float = 3.0
    video_retention_hours: int = 48


@lru_cache
def get_settings() -> Settings:
    return Settings()
