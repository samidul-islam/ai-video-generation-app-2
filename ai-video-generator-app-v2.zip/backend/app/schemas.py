from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field, model_validator

AudioMode = Literal["native", "hq_bengali"]
TTSProvider = Literal["google_chirp", "elevenlabs"]
Resolution = Literal["360p", "540p", "720p", "1080p"]
AspectRatio = Literal["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "3:2", "2:3"]
GenerationMode = Literal["text-to-video", "image-to-video"]
ProjectStatus = Literal["draft", "queued", "rendering", "completed", "failed", "cancelled"]

TERMINAL_STATUSES: set[str] = {"completed", "failed", "cancelled"}


class ParsePromptRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    character_count: int = Field(default=0, ge=0, le=4)


class ParsedPrompt(BaseModel):
    visual_prompt: str
    character_mapping: str
    dialogue: str
    sound_effects: str
    full_minimax_prompt: str
    detected_language: str | None = None


class GenerateAudioRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2500)
    provider: TTSProvider = "google_chirp"
    voice: str | None = Field(default=None, max_length=120)


class GenerateAudioResponse(BaseModel):
    audio_url: str
    provider: TTSProvider
    content_type: str


class GenerateVideoRequest(BaseModel):
    title: str | None = Field(default=None, max_length=120)
    mode: GenerationMode = "text-to-video"
    raw_prompt: str = Field(min_length=1, max_length=4000)
    parsed_prompt: ParsedPrompt | None = None
    audio_mode: AudioMode = "native"
    tts_provider: TTSProvider | None = None
    audio_url: str | None = None
    reference_image_urls: list[str] = Field(default_factory=list, max_length=4)
    resolution: Resolution = "540p"
    aspect_ratio: AspectRatio = "9:16"
    duration_seconds: int = Field(default=8, ge=1, le=20)

    @model_validator(mode="after")
    def validate_mode(self):
        if self.mode == "image-to-video" and not self.reference_image_urls:
            raise ValueError("Image-to-video needs a reference image.")
        return self


class GenerateVideoResponse(BaseModel):
    project_id: str
    job_id: str
    status: ProjectStatus
    credits_charged: int
    balance: int


class Project(BaseModel):
    id: str
    user_id: str
    title: str
    mode: GenerationMode = "text-to-video"
    raw_prompt: str
    parsed_prompt: ParsedPrompt | None = None
    audio_mode: AudioMode
    tts_provider: TTSProvider | None = None
    audio_url: str | None = None
    reference_image_urls: list[str] = Field(default_factory=list)
    resolution: Resolution = "540p"
    aspect_ratio: AspectRatio = "9:16"
    duration_seconds: int = 8
    status: ProjectStatus = "draft"
    progress: int = 0
    status_message: str | None = None
    runpod_job_id: str | None = None
    video_url_720p: str | None = None
    video_url_1080p: str | None = None
    thumbnail_url: str | None = None
    error: str | None = None
    credits_charged: int = 0
    credits_refunded: bool = False
    expires_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class ProjectCreate(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    raw_prompt: str = Field(min_length=1, max_length=4000)
    parsed_prompt: ParsedPrompt | None = None
    audio_mode: AudioMode = "native"
    tts_provider: TTSProvider | None = None
    audio_url: str | None = None
    reference_image_urls: list[str] = Field(default_factory=list, max_length=4)
    resolution: Resolution = "540p"


class ProjectUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    raw_prompt: str | None = Field(default=None, min_length=1, max_length=4000)
    parsed_prompt: ParsedPrompt | None = None
    audio_mode: AudioMode | None = None
    tts_provider: TTSProvider | None = None
    audio_url: str | None = None
    reference_image_urls: list[str] | None = Field(default=None, max_length=4)
    resolution: Resolution | None = None


class ProjectList(BaseModel):
    items: list[Project]
    total: int | None = None


class JobEvent(BaseModel):
    project_id: str
    status: ProjectStatus
    progress: int
    message: str | None
    project: Project


class CreditsResponse(BaseModel):
    balance: int
    video_cost: int
    audio_cost: int


class UploadResponse(BaseModel):
    urls: list[str]


# ---------- App configuration (stored in Firestore `app_config/*`) ----------


class CreditConfig(BaseModel):
    per_second_360p: float = Field(default=1, ge=0)
    per_second_540p: float = Field(default=2, ge=0)
    per_second_720p: float = Field(default=3, ge=0)
    per_second_1080p: float = Field(default=5, ge=0)
    native_audio_charge: float = Field(default=5, ge=0)
    starting_credits: int = Field(default=100, ge=0)


class AppMeta(BaseModel):
    name: str = "Chobi Studio"
    tagline: str = "Script to screen, in any language"
    description: str = "Turn Bengali, Banglish or English prompts into talking-avatar videos."
    logo_url: str = ""
    favicon_url: str = ""
    support_email: str = ""
    maintenance_mode: bool = False
    allow_signups: bool = True
    video_retention_hours: int = Field(default=48, ge=1, le=720)


class GeminiConfig(BaseModel):
    api_key: str = ""
    model: str = "gemini-2.5-flash"
    temperature: float = Field(default=0.4, ge=0, le=2)


class ElevenLabsConfig(BaseModel):
    api_key: str = ""
    voice_id: str = ""
    model_id: str = "eleven_v3"


class GoogleTtsConfig(BaseModel):
    api_key: str = ""
    language: str = "bn-IN"
    voice: str = "bn-IN-Chirp3-HD-Achernar"


class RunPodConfig(BaseModel):
    api_key: str = ""
    endpoint_id: str = ""
    webhook_secret: str = ""


class FirebaseClientConfig(BaseModel):
    api_key: str = ""
    auth_domain: str = ""
    project_id: str = ""
    storage_bucket: str = ""
    app_id: str = ""


class AppSettings(BaseModel):
    meta: AppMeta = Field(default_factory=AppMeta)
    gemini: GeminiConfig = Field(default_factory=GeminiConfig)
    elevenlabs: ElevenLabsConfig = Field(default_factory=ElevenLabsConfig)
    google_tts: GoogleTtsConfig = Field(default_factory=GoogleTtsConfig)
    runpod: RunPodConfig = Field(default_factory=RunPodConfig)
    firebase: FirebaseClientConfig = Field(default_factory=FirebaseClientConfig)


class ThemeConfig(BaseModel):
    primary: str = "#8b5cf6"
    accent: str = "#22d3ee"
    background: str = "#0b0b12"
    surface: str = "#15151f"
    foreground: str = "#f4f4f7"
    radius: float = Field(default=0.9, ge=0, le=2)
    font: Literal["geist", "inter", "system"] = "geist"
    hero_title: str = "What will you create today?"
    hero_subtitle: str = "Describe a scene in Bengali, Banglish or English. Put dialogue in quotes."
    create_label: str = "Create"
    prompt_placeholder: str = (
        'Describe the video. For the cleanest speech, put exact dialogue inside "quotes".'
    )


class PublicConfig(BaseModel):
    meta: AppMeta
    credits: CreditConfig
    theme: ThemeConfig


# ---------- Admin ----------


class UserProfile(BaseModel):
    id: str
    name: str = ""
    username: str = ""
    email: str = ""
    phone: str = ""
    country: str = ""
    photo_url: str = ""
    credits: int = 0
    role: Literal["user", "admin"] = "user"
    disabled: bool = False
    created_at: datetime | None = None


class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    username: str = Field(min_length=2, max_length=40, pattern=r"^[a-zA-Z0-9_.-]+$")
    email: EmailStr
    phone: str = Field(default="", max_length=30)
    country: str = Field(default="", max_length=60)
    photo_url: str = Field(default="", max_length=1000)
    password: str = Field(min_length=6, max_length=128)
    credits: int = Field(default=100, ge=0)
    role: Literal["user", "admin"] = "user"


class UserUpdate(BaseModel):
    name: str | None = Field(default=None, max_length=120)
    username: str | None = Field(default=None, min_length=2, max_length=40, pattern=r"^[a-zA-Z0-9_.-]+$")
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=30)
    country: str | None = Field(default=None, max_length=60)
    photo_url: str | None = Field(default=None, max_length=1000)
    password: str | None = Field(default=None, min_length=6, max_length=128)
    credits: int | None = Field(default=None, ge=0)
    role: Literal["user", "admin"] | None = None
    disabled: bool | None = None


class UserList(BaseModel):
    items: list[UserProfile]


class HistoryItem(Project):
    user_email: str = ""
    user_name: str = ""


class HistoryList(BaseModel):
    items: list[HistoryItem]


class DailyPoint(BaseModel):
    date: str
    videos: int
    credits: int


class AdminStats(BaseModel):
    total_users: int
    total_videos: int
    completed_videos: int
    failed_videos: int
    active_jobs: int
    credits_consumed: int
    daily: list[DailyPoint]
    resolution_split: dict[str, int]
    audio_split: dict[str, int]


class MeResponse(BaseModel):
    profile: UserProfile
    is_admin: bool
