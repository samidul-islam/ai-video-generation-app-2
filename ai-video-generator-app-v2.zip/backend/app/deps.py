from dataclasses import dataclass

from fastapi import Depends, Header, HTTPException, Query, status
from starlette.concurrency import run_in_threadpool

from app.core.config import get_settings
from app.core.http import get_http_client
from app.db.base import ProjectRepository

_repository: ProjectRepository | None = None


def get_repository() -> ProjectRepository:
    global _repository
    if _repository is None:
        if get_settings().db_provider == "firebase":
            from app.db.firebase_repository import FirebaseRepository

            _repository = FirebaseRepository()
        else:
            from app.db.supabase_repository import SupabaseRepository

            _repository = SupabaseRepository()
    return _repository


@dataclass
class AuthUser:
    uid: str
    email: str = ""
    name: str = ""
    is_admin_claim: bool = False


async def _verify_supabase_token(token: str) -> AuthUser:
    settings = get_settings()
    response = await get_http_client().get(
        f"{settings.supabase_url.rstrip('/')}/auth/v1/user",
        headers={"apikey": settings.supabase_service_role_key, "Authorization": f"Bearer {token}"},
    )
    if response.status_code != 200:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired session.")
    body = response.json()
    return AuthUser(uid=body["id"], email=body.get("email", ""))


async def _verify_firebase_token(token: str) -> AuthUser:
    from firebase_admin import auth

    from app.db.firebase_repository import get_firebase_app

    try:
        claims = await run_in_threadpool(auth.verify_id_token, token, get_firebase_app(), True)
    except Exception as exc:  # firebase_admin raises several token error types
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired session.") from exc
    return AuthUser(
        uid=claims["uid"],
        email=claims.get("email", ""),
        name=claims.get("name", ""),
        is_admin_claim=bool(claims.get("admin")),
    )


async def get_auth_user(
    authorization: str | None = Header(default=None),
    access_token: str | None = Query(default=None, include_in_schema=False),
) -> AuthUser:
    """EventSource cannot set headers, so SSE clients may pass ?access_token=."""
    settings = get_settings()
    token = None
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:]
    elif access_token:
        token = access_token

    if token:
        if settings.db_provider == "firebase":
            return await _verify_firebase_token(token)
        return await _verify_supabase_token(token)
    if settings.auth_required:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Authentication required.")
    return AuthUser(uid=settings.dev_user_id, email="dev@localhost", name="Developer", is_admin_claim=True)


async def get_current_user(user: AuthUser = Depends(get_auth_user)) -> str:
    return user.uid


async def require_admin(user: AuthUser = Depends(get_auth_user)) -> AuthUser:
    if user.is_admin_claim:
        return user
    if user.email and user.email.lower() in {e.lower() for e in get_settings().admin_emails}:
        return user

    from app.db.admin_store import get_admin_store

    profile = await get_admin_store().ensure_profile(user.uid, user.email, user.name)
    if profile.role != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Admin access required.")
    return user
