"""Credit cost calculation. Mirrors lib/pricing.ts on the frontend so the Create button shows the exact charge."""

import math

from app.schemas import CreditConfig, Resolution


def video_cost(config: CreditConfig, resolution: Resolution, duration_seconds: int, native_audio: bool) -> int:
    per_second = {
        "360p": config.per_second_360p,
        "540p": config.per_second_540p,
        "720p": config.per_second_720p,
        "1080p": config.per_second_1080p,
    }[resolution]
    total = per_second * duration_seconds + (config.native_audio_charge if native_audio else 0)
    return max(1, math.ceil(total))
