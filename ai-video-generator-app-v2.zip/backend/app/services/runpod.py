from typing import Any

import httpx

from app.core.config import get_settings
from app.core.errors import NotConfiguredError, UpstreamError
from app.core.http import get_http_client

RUNPOD_BASE_URL = "https://api.runpod.ai/v2"


def _endpoint_url(path: str) -> tuple[str, dict[str, str]]:
    settings = get_settings()
    if not settings.runpod_api_key or not settings.runpod_endpoint_id:
        raise NotConfiguredError("RunPod")
    return (
        f"{RUNPOD_BASE_URL}/{settings.runpod_endpoint_id}/{path}",
        {"Authorization": f"Bearer {settings.runpod_api_key}"},
    )


async def _request(method: str, path: str, json: dict | None = None) -> dict[str, Any]:
    url, headers = _endpoint_url(path)
    try:
        response = await get_http_client().request(method, url, json=json, headers=headers)
    except httpx.HTTPError as exc:
        raise UpstreamError("RunPod", f"request failed: {exc}") from exc
    if response.status_code >= 400:
        raise UpstreamError("RunPod", response.text[:500])
    return response.json()


async def submit_job(job_input: dict[str, Any], webhook_url: str | None = None) -> str:
    body: dict[str, Any] = {"input": job_input, "policy": {"executionTimeout": 30 * 60 * 1000}}
    if webhook_url:
        body["webhook"] = webhook_url
    data = await _request("POST", "run", json=body)
    job_id = data.get("id")
    if not job_id:
        raise UpstreamError("RunPod", "no job id returned")
    return job_id


async def get_status(job_id: str) -> dict[str, Any]:
    return await _request("GET", f"status/{job_id}")


async def cancel_job(job_id: str) -> dict[str, Any]:
    return await _request("POST", f"cancel/{job_id}")
