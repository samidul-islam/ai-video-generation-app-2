from typing import Protocol
from urllib.parse import quote

import httpx
from starlette.concurrency import run_in_threadpool

from app.core.config import get_settings
from app.core.errors import NotConfiguredError, UpstreamError
from app.core.http import get_http_client


class StorageBackend(Protocol):
    async def upload(self, path: str, data: bytes, content_type: str) -> str: ...

    def is_owned_url(self, url: str) -> bool: ...


class SupabaseStorage:
    def __init__(self) -> None:
        settings = get_settings()
        if not settings.supabase_url or not settings.supabase_service_role_key:
            raise NotConfiguredError("Supabase Storage")
        self._base = settings.supabase_url.rstrip("/")
        self._bucket = settings.supabase_storage_bucket
        self._key = settings.supabase_service_role_key

    @property
    def public_prefix(self) -> str:
        return f"{self._base}/storage/v1/object/public/{self._bucket}/"

    async def upload(self, path: str, data: bytes, content_type: str) -> str:
        encoded = quote(path)
        try:
            response = await get_http_client().post(
                f"{self._base}/storage/v1/object/{self._bucket}/{encoded}",
                content=data,
                headers={
                    "Authorization": f"Bearer {self._key}",
                    "apikey": self._key,
                    "Content-Type": content_type,
                    "x-upsert": "true",
                    "cache-control": "31536000",
                },
            )
        except httpx.HTTPError as exc:
            raise UpstreamError("Supabase Storage", f"upload failed: {exc}") from exc
        if response.status_code >= 400:
            raise UpstreamError("Supabase Storage", response.text[:300])
        return f"{self.public_prefix}{encoded}"

    def is_owned_url(self, url: str) -> bool:
        return url.startswith(self.public_prefix)


class FirebaseStorage:
    def __init__(self) -> None:
        from app.db.firebase_repository import get_firebase_app

        settings = get_settings()
        if not settings.firebase_storage_bucket:
            raise NotConfiguredError("Firebase Storage")
        from firebase_admin import storage

        self._bucket = storage.bucket(settings.firebase_storage_bucket, app=get_firebase_app())

    @property
    def public_prefix(self) -> str:
        return f"https://storage.googleapis.com/{self._bucket.name}/"

    async def upload(self, path: str, data: bytes, content_type: str) -> str:
        def _upload() -> str:
            blob = self._bucket.blob(path)
            blob.cache_control = "public, max-age=31536000"
            blob.upload_from_string(data, content_type=content_type)
            blob.make_public()
            return blob.public_url

        return await run_in_threadpool(_upload)

    def is_owned_url(self, url: str) -> bool:
        return url.startswith(self.public_prefix)


_storage: StorageBackend | None = None


def get_storage() -> StorageBackend:
    global _storage
    if _storage is None:
        _storage = FirebaseStorage() if get_settings().db_provider == "firebase" else SupabaseStorage()
    return _storage
