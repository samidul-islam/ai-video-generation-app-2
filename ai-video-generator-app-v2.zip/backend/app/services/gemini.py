import json

import httpx
from pydantic import ValidationError

from app.core.config import get_settings
from app.core.errors import NotConfiguredError, UpstreamError
from app.core.http import get_http_client
from app.schemas import ParsedPrompt

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

SYSTEM_INSTRUCTION = """You are the creative director for an AI talking-avatar video generator.
Users write in Bengali (বাংলা), Banglish (Bengali written in Latin script, e.g. "ami tomake bhalobashi"), or English, often mixed.

Your job is to convert the user's idea into a structured production brief:

- visual_prompt: A vivid, cinematic ENGLISH description of the shot. Include subject, setting, lighting, camera framing and movement, mood, and art style. Never include dialogue text here.
- character_mapping: How each uploaded reference image maps to a character, e.g. "Image 1 = the grandmother (speaking), Image 2 = the child (listening)". If no images were provided, describe the characters to be generated.
- dialogue: The spoken lines in natural, grammatically correct BENGALI SCRIPT (বাংলা লিপি). Transliterate Banglish into Bengali script and translate English into Bengali. Keep it short enough to be spoken in the target duration. Use an empty string if nobody speaks.
- sound_effects: Ambient sound and SFX in English (e.g. "soft monsoon rain, distant rickshaw bells").
- full_minimax_prompt: A single combined English prompt for the video model that merges visuals, character actions, lip-sync cues ("the woman speaks warmly to camera"), and sound design. Refer to characters by their image number when images were provided.

Respond ONLY with JSON matching the provided schema."""

RESPONSE_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "visual_prompt": {"type": "STRING"},
        "character_mapping": {"type": "STRING"},
        "dialogue": {"type": "STRING"},
        "sound_effects": {"type": "STRING"},
        "full_minimax_prompt": {"type": "STRING"},
    },
    "required": [
        "visual_prompt",
        "character_mapping",
        "dialogue",
        "sound_effects",
        "full_minimax_prompt",
    ],
    "propertyOrdering": [
        "visual_prompt",
        "character_mapping",
        "dialogue",
        "sound_effects",
        "full_minimax_prompt",
    ],
}


async def parse_prompt(text: str, character_count: int) -> ParsedPrompt:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise NotConfiguredError("Gemini")

    user_message = (
        f"Reference images uploaded: {character_count}\n\n"
        f"User idea:\n{text}"
    )
    body = {
        "systemInstruction": {"parts": [{"text": SYSTEM_INSTRUCTION}]},
        "contents": [{"role": "user", "parts": [{"text": user_message}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": RESPONSE_SCHEMA,
            "temperature": 0.6,
        },
    }

    client = get_http_client()
    try:
        response = await client.post(
            f"{GEMINI_BASE_URL}/{settings.gemini_model}:generateContent",
            json=body,
            headers={"x-goog-api-key": settings.gemini_api_key},
        )
    except httpx.HTTPError as exc:
        raise UpstreamError("Gemini", f"request failed: {exc}") from exc

    if response.status_code >= 400:
        raise UpstreamError("Gemini", response.text[:500])

    try:
        payload = response.json()
        raw_json = payload["candidates"][0]["content"]["parts"][0]["text"]
        return ParsedPrompt.model_validate(json.loads(raw_json))
    except (KeyError, IndexError, json.JSONDecodeError, ValidationError) as exc:
        raise UpstreamError("Gemini", f"unexpected response shape: {exc}") from exc
