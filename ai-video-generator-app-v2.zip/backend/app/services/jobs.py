import logging
from typing import Any

from app.db.base import ProjectRepository
from app.schemas import TERMINAL_STATUSES, Project
from app.services import runpod

logger = logging.getLogger(__name__)

FAILED_RUNPOD_STATUSES = {"FAILED", "CANCELLED", "TIMED_OUT"}


def parse_progress(raw: Any) -> tuple[int | None, str | None]:
    """The worker reports progress as "<percent>|<message>" via runpod.serverless.progress_update."""
    if isinstance(raw, str) and "|" in raw:
        percent, message = raw.split("|", 1)
        try:
            return max(0, min(99, int(percent))), message.strip() or None
        except ValueError:
            return None, raw
    if isinstance(raw, str):
        return None, raw
    return None, None


async def _fail(repo: ProjectRepository, project: Project, error: str) -> Project:
    updated = await repo.update_project(
        project.id,
        {"status": "failed", "error": error[:1000], "status_message": "Generation failed"},
    )
    if project.credits_charged > 0 and await repo.mark_refunded(project.id):
        await repo.refund_credits(project.user_id, project.credits_charged)
        updated = updated.model_copy(update={"credits_refunded": True})
    return updated


async def apply_runpod_payload(
    repo: ProjectRepository, project: Project, payload: dict[str, Any]
) -> Project:
    if project.status in TERMINAL_STATUSES:
        return project

    runpod_status = payload.get("status")

    if runpod_status == "IN_QUEUE":
        updates = {
            "status": "queued",
            "progress": max(project.progress, 10),
            "status_message": "Waiting for a GPU worker",
        }
    elif runpod_status == "IN_PROGRESS":
        percent, message = parse_progress(payload.get("output"))
        updates = {
            "status": "rendering",
            "progress": max(project.progress, percent if percent is not None else 25),
            "status_message": message or "Rendering video",
        }
    elif runpod_status == "COMPLETED":
        output = payload.get("output") or {}
        if not isinstance(output, dict) or output.get("error") or not output.get("video_url_1080p"):
            error = output.get("error") if isinstance(output, dict) else None
            return await _fail(repo, project, error or "Worker returned no video.")
        updates = {
            "status": "completed",
            "progress": 100,
            "status_message": "Your video is ready",
            "video_url_1080p": output.get("video_url_1080p"),
            "video_url_720p": output.get("video_url_720p"),
            "thumbnail_url": output.get("thumbnail_url"),
        }
    elif runpod_status in FAILED_RUNPOD_STATUSES:
        return await _fail(repo, project, str(payload.get("error") or f"Job {runpod_status.lower()}"))
    else:
        return project

    if all(getattr(project, key) == value for key, value in updates.items()):
        return project
    return await repo.update_project(project.id, updates)


async def sync_project_with_runpod(repo: ProjectRepository, project: Project) -> Project:
    if project.status in TERMINAL_STATUSES or not project.runpod_job_id:
        return project
    payload = await runpod.get_status(project.runpod_job_id)
    return await apply_runpod_payload(repo, project, payload)
