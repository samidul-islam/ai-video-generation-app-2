import base64
from dataclasses import dataclass

import httpx

from app.core.config import get_settings
from app.core.errors import NotConfiguredError, UpstreamError
from app.core.http import get_http_client
from app.schemas import TTSProvider


@dataclass
class SynthesizedAudio:
    data: bytes
    content_type: str
    extension: str


async def synthesize_google_chirp(text: str, voice: str | None) -> SynthesizedAudio:
    settings = get_settings()
    if not settings.google_tts_api_key:
        raise NotConfiguredError("Google Cloud TTS")

    body = {
        "input": {"text": text},
        "voice": {
            "languageCode": settings.google_tts_language,
            "name": voice or settings.google_tts_voice,
        },
        "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": 24000},
    }
    try:
        response = await get_http_client().post(
            "https://texttospeech.googleapis.com/v1/text:synthesize",
            json=body,
            headers={"x-goog-api-key": settings.google_tts_api_key},
        )
    except httpx.HTTPError as exc:
        raise UpstreamError("Google Cloud TTS", f"request failed: {exc}") from exc

    if response.status_code >= 400:
        raise UpstreamError("Google Cloud TTS", response.text[:500])

    audio_content = response.json().get("audioContent")
    if not audio_content:
        raise UpstreamError("Google Cloud TTS", "empty audio response")

    # LINEAR16 responses include a RIFF/WAV header, so the bytes are a playable .wav file.
    return SynthesizedAudio(base64.b64decode(audio_content), "audio/wav", "wav")


async def synthesize_elevenlabs(text: str, voice: str | None) -> SynthesizedAudio:
    settings = get_settings()
    voice_id = voice or settings.elevenlabs_voice_id
    if not settings.elevenlabs_api_key or not voice_id:
        raise NotConfiguredError("ElevenLabs")

    try:
        response = await get_http_client().post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            params={"output_format": "mp3_44100_128"},
            json={
                "text": text,
                "model_id": settings.elevenlabs_model_id,
                "language_code": "bn",
            },
            headers={"xi-api-key": settings.elevenlabs_api_key, "Accept": "audio/mpeg"},
        )
    except httpx.HTTPError as exc:
        raise UpstreamError("ElevenLabs", f"request failed: {exc}") from exc

    if response.status_code >= 400:
        raise UpstreamError("ElevenLabs", response.text[:500])

    return SynthesizedAudio(response.content, "audio/mpeg", "mp3")


async def synthesize(provider: TTSProvider, text: str, voice: str | None) -> SynthesizedAudio:
    if provider == "elevenlabs":
        return await synthesize_elevenlabs(text, voice)
    return await synthesize_google_chirp(text, voice)
