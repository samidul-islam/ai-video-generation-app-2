-- Run in the Supabase SQL editor.
-- The FastAPI backend uses the service-role key and scopes every query by user_id.
-- RLS policies below protect direct client access with the anon key.

create extension if not exists "pgcrypto";

create table if not exists public.user_credits (
  user_id uuid primary key,
  balance integer not null check (balance >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  title text not null,
  raw_prompt text not null,
  parsed_prompt jsonb,
  audio_mode text not null default 'native' check (audio_mode in ('native', 'hq_bengali')),
  tts_provider text check (tts_provider in ('google_chirp', 'elevenlabs')),
  audio_url text,
  reference_image_urls text[] not null default '{}',
  resolution text not null default '1080p' check (resolution in ('720p', '1080p')),
  status text not null default 'draft'
    check (status in ('draft', 'queued', 'rendering', 'completed', 'failed', 'cancelled')),
  progress integer not null default 0 check (progress between 0 and 100),
  status_message text,
  runpod_job_id text,
  video_url_720p text,
  video_url_1080p text,
  thumbnail_url text,
  error text,
  credits_charged integer not null default 0,
  credits_refunded boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists projects_user_created_idx on public.projects (user_id, created_at desc);
create index if not exists projects_runpod_job_idx on public.projects (runpod_job_id);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists projects_touch_updated_at on public.projects;
create trigger projects_touch_updated_at
  before update on public.projects
  for each row execute function public.touch_updated_at();

alter table public.projects enable row level security;
alter table public.user_credits enable row level security;

drop policy if exists "Users read own projects" on public.projects;
create policy "Users read own projects" on public.projects
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Users read own credits" on public.user_credits;
create policy "Users read own credits" on public.user_credits
  for select to authenticated using (auth.uid() = user_id);

-- Credit functions: atomic, callable only by the service role.

create or replace function public.get_credits(p_user_id uuid, p_starting integer default 100)
returns integer language plpgsql security definer set search_path = public as $$
declare
  v_balance integer;
begin
  insert into user_credits (user_id, balance) values (p_user_id, p_starting)
  on conflict (user_id) do nothing;
  select balance into v_balance from user_credits where user_id = p_user_id;
  return v_balance;
end;
$$;

create or replace function public.consume_credits(p_user_id uuid, p_amount integer, p_starting integer default 100)
returns integer language plpgsql security definer set search_path = public as $$
declare
  v_balance integer;
begin
  if p_amount <= 0 then
    raise exception 'invalid_amount';
  end if;
  insert into user_credits (user_id, balance) values (p_user_id, p_starting)
  on conflict (user_id) do nothing;
  update user_credits
     set balance = balance - p_amount, updated_at = now()
   where user_id = p_user_id and balance >= p_amount
  returning balance into v_balance;
  if v_balance is null then
    raise exception 'insufficient_credits';
  end if;
  return v_balance;
end;
$$;

create or replace function public.refund_credits(p_user_id uuid, p_amount integer)
returns integer language plpgsql security definer set search_path = public as $$
declare
  v_balance integer;
begin
  update user_credits
     set balance = balance + greatest(p_amount, 0), updated_at = now()
   where user_id = p_user_id
  returning balance into v_balance;
  return coalesce(v_balance, 0);
end;
$$;

revoke all on function public.get_credits(uuid, integer) from public, anon, authenticated;
revoke all on function public.consume_credits(uuid, integer, integer) from public, anon, authenticated;
revoke all on function public.refund_credits(uuid, integer) from public, anon, authenticated;
grant execute on function public.get_credits(uuid, integer) to service_role;
grant execute on function public.consume_credits(uuid, integer, integer) to service_role;
grant execute on function public.refund_credits(uuid, integer) to service_role;

-- Public bucket for reference images, TTS audio and rendered videos.
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;
